package kr.co.koo.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//서블릿 클래스 선언 방법: HttpServlet클래스를 상속받습니다.
//URL Mapping: 페이지의 URL을 사용자 정의로 지정하는 방식
@WebServlet("/apple")
public class ServletBasic extends HttpServlet {
	
	//기본 생성자 선언.
	public ServletBasic() {
		System.out.println("apple페이지 서블릿 객체 생성!");
	}
	
	//HttpServlet클래스에서 상속받은 메서드들을 오버라이딩합니다.
	//init(), doGet(), doPost(), destory() 등
	@Override
	public void init() throws ServletException {
		/*
		 페이지 요청이 들어왔을 때 처음 실행할 로직을 작성.
		 init()메서드는 컨테이너에 의해 서블릿 객체가 생성될 때
		 최초 1회 자동 호출됩니다.
		 */
		System.out.println("init메서드가 호출됨!");
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//Http Get요청이 들어왔을 때 호출되는 메서드.
		System.out.println("doGet메서드 호출!");
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//Http Post요청이 들어왔을 때 호출되는 메서드.
		System.out.println("doPost메서드 호출!");
	}
	
	@Override
	public void destroy() {
		//서블릿 객체가 소멸할 때 호출되는 메서드(객체 소멸시 1회 호출)
		System.out.println("destroy메서드 호출!");
	}
	
}






