
public class Basic {
			
	public int i;
	public String str = "홍길동";
	
	public static int add(int n1, int n2) {
		return n1 + n2;
	}	
	
	public static void main(String[] args) {
		int result = add(10, 5);
		double d = Math.random();
		
	}

}
