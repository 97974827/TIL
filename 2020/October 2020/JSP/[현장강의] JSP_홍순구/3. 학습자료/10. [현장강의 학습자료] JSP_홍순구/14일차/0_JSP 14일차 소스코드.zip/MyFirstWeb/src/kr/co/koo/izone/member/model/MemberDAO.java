package kr.co.koo.izone.member.model;

import java.sql.*;
import java.util.*;
import javax.sql.DataSource;

import kr.co.koo.izone.util.JdbcUtil;

import javax.naming.*;

public class MemberDAO {

	private static MemberDAO dao = new MemberDAO();
	private DataSource ds;

	private MemberDAO() {
		try {
			Context ct = new InitialContext();
			ds = (DataSource)ct.lookup("java:comp/env/jdbc/mysql");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static MemberDAO getInstance() {
		if(dao == null) {
			dao = new MemberDAO();
		}
		return dao;
	}

	//ID 중복확인을 하는 메서드 선언.
	public boolean confirmId(String id) {

		boolean flag = false;

		String sql = "SELECT user_id FROM izone_member"
				+ " WHERE user_id=?";

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);

			rs = pstmt.executeQuery();

			if(rs.next()) {
				flag = true;
			} else {
				flag = false;
			}			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn);
			JdbcUtil.close(pstmt);
			JdbcUtil.close(rs);
		}
		return flag;
	}

	//회원가입을 수행하는 메서드 선언.
	public boolean insertMember(MemberVO members) {
		boolean flag = false;

		String sql = "INSERT INTO izone_member "
				+ "(user_id, user_pw, user_name, user_email) "
				+ "VALUES (?,?,?,?)";
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, members.getUserId());
			pstmt.setString(2, members.getUserPw());
			pstmt.setString(3, members.getUserName());
			pstmt.setString(4, members.getUserEmail());

			int i = pstmt.executeUpdate();

			if(i == 1) {
				flag = true;				
			} else {
				flag = false;	
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn);
			JdbcUtil.close(pstmt);
		}		
		return flag;
	}

}









