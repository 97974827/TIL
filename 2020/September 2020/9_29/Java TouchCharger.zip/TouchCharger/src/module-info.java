//
//module fxtest {
//	exports application;
////	exports application.view;
////	exports application.util;
//	
//	
//	opens application.view to javafx.fxml;
//	opens application.util to javafx.fxml;
//	
//	
//	requires javafx.base;
//	requires javafx.graphics;
//	requires javafx.fxml;
//	requires javafx.controls;
//	requires java.smartcardio;
//	requires javafx.media;
//	requires javafx.web;
//	requires javafx.swing;
//	
//	requires java.naming;
//}