package application.util;

import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import application.Main;
import javafx.application.Platform;


public class DataBaseUtil {
	
    private final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    private final String MYSQL_HOST = "jdbc:mysql://glstest.iptime.org:30002/glstech?characterEncoding=utf8&serverTimezone=UTC";
//  private final String MYSQL_HOST = "jdbc:mysql://localhost:3306/glstech?characterEncoding=utf8&serverTimezone=UTC";
    private final String MYSQL_USER = "pi";
    private final String MYSQL_PWD = "1234";

    private Map<String, String> map_config_data = new HashMap<String, String>(); // 설정 데이터 
    private Map<Long, String> map_crc_data = new HashMap<Long, String>();  // Crc 데이터
    public Map<String, String> manager_list = new HashMap<String, String>(); // 업체 - 저장번지
	
	// TODO : Test
	public static void main(String[] args) {
//		DataBaseUtil database = new DataBaseUtil();
//		System.out.println(database.getConfigData());
//		System.out.println(database.getCrcData());
	}
	
	public DataBaseUtil() {
		Connection conn = null; // DB conn  
		Statement stmt = null;  // sql 실행 객체
		ResultSet rs = null;    // sql 결과 객체
		
		try {
			Class.forName(JDBC_DRIVER); // 1. driver loading 
			conn = DriverManager.getConnection(MYSQL_HOST, MYSQL_USER, MYSQL_PWD); // 2. connect(url, user, password)
			stmt = conn.createStatement();  // 3. to query execute Statement object add			
			String sql = "SELECT * FROM crc ORDER BY no"; // 4. SQL query 
			rs = stmt.executeQuery(sql);    // 5. query execute
			
			while(rs.next()) { 
				long no = rs.getLong(1); // param : Column index (1)   
				String crc_value = rs.getString("crc");
				
				map_crc_data.put(no, crc_value);
			}
			 
			// Print
//			for (Map.Entry<Integer, String> elem : map_crc_data.entrySet()){
//			    int key_no = elem.getKey();
//	            String value_crc = elem.getValue();
//	 
//	            System.out.println(key_no + " : " + value_crc);
//	        }
			
			sql = "SELECT `con`.master_password as master_password, `con`.gil_password as gil_password, "
					+ "`con`.admin_password as admin_password, `con`.device_addr as device_addr, "
					+ "`con`.card_price as card_price, `con`.min_card_price as min_card_price, "
					+ "`con`.bonus1 as bonus1, `con`.bonus2 as bonus2, `con`.bonus3 as bonus3, `con`.bonus4 as bonus4, `con`.bonus5 as bonus5, "
					+ "`con`.bonus6 as bonus6, `con`.bonus7 as bonus7, `con`.bonus8 as bonus8, `con`.bonus9 as bonus9, `con`.bonus10 as bonus10, "
					+ "`con`.id as id, `con`.version as version, `man`.encrypt as encrypt, `man`.manager_id as manager_id, "
					+ "`con`.data_collect_state as data_collect_state, `con`.manager_no as manager_no FROM config as `con` "
					+ "INNER JOIN manager as `man` ON `con`.manager_no = `man`.no";
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				String master_password = rs.getString("master_password");
				String gil_password = rs.getString("gil_password");
				String admin_password = rs.getString("admin_password");
				String device_addr = rs.getString("device_addr");
				String card_price = rs.getString("card_price");
				String min_card_price = rs.getString("min_card_price");
				String bonus1 = rs.getString("bonus1");
				String bonus2 = rs.getString("bonus2");
				String bonus3 = rs.getString("bonus3");
				String bonus4 = rs.getString("bonus4");
				String bonus5 = rs.getString("bonus5");
				String bonus6 = rs.getString("bonus6");
				String bonus7 = rs.getString("bonus7");
				String bonus8 = rs.getString("bonus8");
				String bonus9 = rs.getString("bonus9");
				String bonus10 = rs.getString("bonus10");
				String id = rs.getString("id");
				String version = rs.getString("version");
				String encrypt = rs.getString("encrypt");
				String manager_id = rs.getString("manager_id");
				String data_collect_state = rs.getString("data_collect_state");
				String manager_no = rs.getString("manager_no");
				
				map_config_data.put("master_password", master_password);
				map_config_data.put("gil_password", gil_password);
				map_config_data.put("admin_password", admin_password);
				map_config_data.put("device_addr", device_addr);
				map_config_data.put("card_price", card_price);
				map_config_data.put("min_card_price", min_card_price);
				map_config_data.put("bonus1", bonus1);
				map_config_data.put("bonus2", bonus2);
				map_config_data.put("bonus3", bonus3);
				map_config_data.put("bonus4", bonus4);
				map_config_data.put("bonus5", bonus5);
				map_config_data.put("bonus6", bonus6);
				map_config_data.put("bonus7", bonus7);
				map_config_data.put("bonus8", bonus8);
				map_config_data.put("bonus9", bonus9);
				map_config_data.put("bonus10", bonus10);
				map_config_data.put("id", id);
				map_config_data.put("version", version);
				map_config_data.put("encrypt", encrypt);
				map_config_data.put("manager_id", manager_id);
				map_config_data.put("data_collect_state", data_collect_state);
				map_config_data.put("manager_no", manager_no);
			}
			
		} catch(ClassNotFoundException e) {
			System.out.println("드라이버 로딩 실패  >> " + e);
			e.printStackTrace();
		} catch(SQLException e) {
			System.out.println("Exception >> " + e);
			e.printStackTrace();
		} finally {
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
				}
				if(stmt != null && !stmt.isClosed()) {
					stmt.close();
				}
				if(conn != null && !conn.isClosed()) {
					conn.close();
				}
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
		
		getManagerList();
	}
	
	public void loadConfig() {
		Connection conn = null; // DB conn  
		Statement stmt = null;  // sql 실행 객체
		ResultSet rs = null;    // sql 결과 객체
		
		try {
			Class.forName(JDBC_DRIVER); // 1. driver loading 
			conn = DriverManager.getConnection(MYSQL_HOST, MYSQL_USER, MYSQL_PWD); // 2. connect(url, user, password)
			stmt = conn.createStatement();  // 3. to query execute Statement object add			
			
			// Print
//			for (Map.Entry<Integer, String> elem : map_crc_data.entrySet()){
//			    int key_no = elem.getKey();
//	            String value_crc = elem.getValue();
//	 
//	            System.out.println(key_no + " : " + value_crc);
//	        }
			
			String sql = "SELECT `con`.master_password as master_password, `con`.gil_password as gil_password, "
					+ "`con`.admin_password as admin_password, `con`.device_addr as device_addr, "
					+ "`con`.card_price as card_price, `con`.min_card_price as min_card_price, "
					+ "`con`.bonus1 as bonus1, `con`.bonus2 as bonus2, `con`.bonus3 as bonus3, `con`.bonus4 as bonus4, `con`.bonus5 as bonus5, "
					+ "`con`.bonus6 as bonus6, `con`.bonus7 as bonus7, `con`.bonus8 as bonus8, `con`.bonus9 as bonus9, `con`.bonus10 as bonus10, "
					+ "`con`.id as id, `con`.version as version, `man`.encrypt as encrypt, `man`.manager_id as manager_id, "
					+ "`con`.data_collect_state as data_collect_state, `con`.manager_no as manager_no FROM config as `con` "
					+ "INNER JOIN manager as `man` ON `con`.manager_no = `man`.no";
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				String master_password = rs.getString("master_password");
				String gil_password = rs.getString("gil_password");
				String admin_password = rs.getString("admin_password");
				String device_addr = rs.getString("device_addr");
				String card_price = rs.getString("card_price");
				String min_card_price = rs.getString("min_card_price");
				String bonus1 = rs.getString("bonus1");
				String bonus2 = rs.getString("bonus2");
				String bonus3 = rs.getString("bonus3");
				String bonus4 = rs.getString("bonus4");
				String bonus5 = rs.getString("bonus5");
				String bonus6 = rs.getString("bonus6");
				String bonus7 = rs.getString("bonus7");
				String bonus8 = rs.getString("bonus8");
				String bonus9 = rs.getString("bonus9");
				String bonus10 = rs.getString("bonus10");
				String id = rs.getString("id");
				String version = rs.getString("version");
				String encrypt = rs.getString("encrypt");
				String manager_id = rs.getString("manager_id");
				String data_collect_state = rs.getString("data_collect_state");
				String manager_no = rs.getString("manager_no");
//			    String rf_reader_type = row['rf_reader_type']
//                self.manager_name = row['manager_name']
//                self.manager_no = row['manager_no']
//                self.manager_key = row['shop_id']
                
                		
				map_config_data.put("master_password", master_password);
				map_config_data.put("gil_password", gil_password);
				map_config_data.put("admin_password", admin_password);
				map_config_data.put("device_addr", device_addr);
				map_config_data.put("card_price", card_price);
				map_config_data.put("min_card_price", min_card_price);
				map_config_data.put("bonus1", bonus1);
				map_config_data.put("bonus2", bonus2);
				map_config_data.put("bonus3", bonus3);
				map_config_data.put("bonus4", bonus4);
				map_config_data.put("bonus5", bonus5);
				map_config_data.put("bonus6", bonus6);
				map_config_data.put("bonus7", bonus7);
				map_config_data.put("bonus8", bonus8);
				map_config_data.put("bonus9", bonus9);
				map_config_data.put("bonus10", bonus10);
				map_config_data.put("id", id);
				map_config_data.put("version", version);
				map_config_data.put("encrypt", encrypt);
				map_config_data.put("manager_id", manager_id);
				map_config_data.put("data_collect_state", data_collect_state);
				map_config_data.put("manager_no", manager_no);
			}
			
		} catch(ClassNotFoundException e) {
			System.out.println("드라이버 로딩 실패  >> " + e);
			e.printStackTrace();
		} catch(SQLException e) {
			System.out.println("Exception >> " + e);
			e.printStackTrace();
		} finally {
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
				}
				if(stmt != null && !stmt.isClosed()) {
					stmt.close();
				}
				if(conn != null && !conn.isClosed()) {
					conn.close();
				}
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public String getJDBC_DRIVER() {
		return JDBC_DRIVER;
	}

	public String getMYSQL_HOST() {
		return MYSQL_HOST;
	}

	public String getMYSQL_USER() {
		return MYSQL_USER;
	}

	public String getMYSQL_PWD() {
		return MYSQL_PWD;
	}
	
	// 충전 / 발급 데이터 저장
	public void setChargeData(String serial_number, int remain_money) {
		Connection conn = null; // DB conn  
		PreparedStatement  stmt = null;  // sql 실행 객체
		ResultSet rs = null;    // sql 결과 객체
		
		try {
			Class.forName(JDBC_DRIVER);  
			conn = DriverManager.getConnection(MYSQL_HOST, MYSQL_USER, MYSQL_PWD); 
			
			String sql = "INSERT INTO card (card_num, total_mny, current_mny, current_bonus, charge_money, before_mny, card_price"
					+ ", kind, datetime, reader_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"; 
			
			stmt = conn.prepareStatement(sql);  
			
			stmt.setString(1, serial_number);
			stmt.setString(6, String.format("%d", remain_money));
			
			int price = 0;
			int kind = 0;
			
			// 충전 / 발급 데이터 분간 
			if (Main.RFID.state_charge) {
				price = 0;
				kind = 1;
				stmt.setString(2, String.format("%d", Main.RFID.TOTAL_MONEY));
				stmt.setString(3, String.format("%d", Main.bill.USE_CURRENT_MONEY));
				stmt.setString(4, String.format("%d", Main.bill.USE_CURRENT_BONUS));
			} else if(Main.RFID.state_issued) {
				price = 1000;
				kind = 0;
				stmt.setString(2, String.format("%d", Main.bill.issued_money));
				stmt.setString(3, String.format("%d", Main.bill.USE_CURRENT_MONEY));
				stmt.setString(4, String.format("%d", Main.bill.USE_CURRENT_BONUS));
			}
			stmt.setString(5, String.format("%d", Main.bill.USE_CURRENT_MONEY + Main.bill.USE_CURRENT_BONUS - price));
			stmt.setString(7, String.format("%d", price));
			stmt.setString(8, String.format("%d", kind));
			
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.KOREA);
			String time = formatter.format(new Date()); 
			stmt.setString(9, time);
			stmt.setString(10, "1");
			
			stmt.executeUpdate(); // 실행
			
		} catch(ClassNotFoundException e) {
			System.out.println("드라이버 로딩 실패  >> " + e);
			e.printStackTrace();
		} catch(SQLException e) {
			System.out.println("Exception >> " + e);
			e.printStackTrace();
		} finally {
			try {
				if(stmt != null && !stmt.isClosed()) {
					stmt.close();
				}
				if(conn != null && !conn.isClosed()) {
					conn.close();
				}
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	// 공급업체 - 카드 저장번지 저장
	public void getManagerList() {
		Connection conn = null; // DB conn  
		Statement stmt = null;  // sql 실행 객체
		ResultSet rs = null;    // sql 결과 객체
		
		try {
			Class.forName(JDBC_DRIVER); // 1. driver loading 
			conn = DriverManager.getConnection(MYSQL_HOST, MYSQL_USER, MYSQL_PWD); // 2. connect(url, user, password)
			stmt = conn.createStatement();  // 3. to query execute Statement object add			
			String sql = "SELECT * FROM manager"; // 4. SQL query 
			rs = stmt.executeQuery(sql);    // 5. query execute
			
			while(rs.next()) { 
				String manager_name = rs.getString("manager_name");
				String binary_addr = rs.getString("encrypt");
				
				if(binary_addr.equals("0")) {
					binary_addr = "1";
				} else {
					binary_addr = "2";
				}
				
				manager_list.put("manager_name", manager_name);
				manager_list.put("binary_addr", binary_addr);
			}
			
		} catch(ClassNotFoundException e) {
			System.out.println("드라이버 로딩 실패  >> " + e);
			e.printStackTrace();
		} catch(SQLException e) {
			System.out.println("Exception >> " + e);
			e.printStackTrace();
		} finally {
			try {
				if(conn != null && !conn.isClosed()) {
					conn.close();
				}
				if(stmt != null && !stmt.isClosed()) {
					stmt.close();
				}
				if(rs != null && !rs.isClosed()) {
					rs.close();
				}
				
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void setConfigData(Map<String, String> map_config_data) {
		this.map_config_data = map_config_data;
	}
	
	public Map<String, String> getConfigData(){
		return map_config_data;
	}
	
	public void setCrcData(Map<Long, String> map_crc_data) {
		this.map_crc_data = map_crc_data;
	}
	
	public Map<Long, String> getCrcData(){
		return map_crc_data;
	}
	
}	
