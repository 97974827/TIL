package application.util;

import java.util.ArrayList;

import application.Main;
import jssc.SerialPort;
import jssc.SerialPortList;


// [카드배출기 관련]
public class EjectorUtil {

	private SerialPort serialPort;

	public boolean EJECTOR_CONN = false;
    public boolean STOP;
	
    public static int card_price = Integer.parseInt(Main.dataBase.getConfigData().get("card_price")); 	      	// 카드 발급금액
    public static int min_card_price = Integer.parseInt(Main.dataBase.getConfigData().get("min_card_price"));	// 카드 발급 최소 금액
    
	public static void main(String[] args) {
		EjectorUtil ejector = new EjectorUtil();
		
	}
	
	public EjectorUtil() {
		 try {
//			String[] portNames = null;
//		    portNames = SerialPortList.getPortNames();
//		    for (String string : portNames) {
//		    	System.out.println(string);
//	        }
			String port = "/dev/ttyUSB0";
            serialPort = new SerialPort(port);
            if (!serialPort.isOpened()) {
            	System.out.println("Ejector Serial Open");
                serialPort.openPort();//Open serial port
                serialPort.setParams(SerialPort.BAUDRATE_9600,
                        SerialPort.DATABITS_8,
                        SerialPort.STOPBITS_1,
                        SerialPort.PARITY_NONE);
        		writeBlock("hi");
//        		writeBlock("enable");
//                writeBlock("output");
//                writeBlock("getActiveStatus");
                readBlock(); 
                writeBlock("init");
                readBlock(); 
            }
            //activeStateThread(); // 지폐인식기 명령 스레드 
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	 public void closeSerial() {
    	try {
    		System.out.println("ejector close");
    		if (!serialPort.isOpened()) { serialPort.closePort(); }
    	} catch(Exception e) {
    		e.printStackTrace();
    	}
    }
	
	public void writeBlock(String command) {
        byte[] buff = new byte[5];
        switch (command) {
            case "hi":
                buff[0] = (byte) 0x24;
                buff[1] = (byte) 0x48;
                buff[2] = (byte) 0x49;
                buff[3] = (byte) 0x3f;
                buff[4] = (byte) 0xd0;
                break;

            case "enable":
                buff[0] = (byte) 0x24;
                buff[1] = (byte) 0x48;
                buff[2] = (byte) 0x43;
                buff[3] = (byte) 0x3f;
                buff[4] = (byte) 0xCA;
                break;

            case "disable":
                buff[0] = (byte) 0x24;
                buff[1] = (byte) 0x48;
                buff[2] = (byte) 0x00;
                buff[3] = (byte) 0x00;
                buff[4] = (byte) 0x48;
                break;

            case "init":
                buff[0] = (byte) 0x24;
                buff[1] = (byte) 0x49;
                buff[2] = (byte) 0x00;
                buff[3] = (byte) 0x00;
                buff[4] = (byte) 0x49;
                break;

            case "getActiveStatus":
                buff[0] = (byte) 0x24;
                buff[1] = (byte) 0x53;
                buff[2] = (byte) 0x00;
                buff[3] = (byte) 0x00;
                buff[4] = (byte) 0x53;
                break;
                
            case "output":
            	buff[0] = (byte) 0x24;
                buff[1] = (byte) 0x44;
                buff[2] = (byte) 0x01;
                buff[3] = (byte) 0x53;
                buff[4] = (byte) 0x98;
                break;
        }
        try {
        	System.out.println(command);
//            serialPort.writeBytes(buff);
        	for(int i=0; i<5; i++) {
            	serialPort.writeByte(buff[i]);
            }
            try { Thread.sleep(1000);} catch (Exception e) {}
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	 public void readBlock() {
		 // TODO : test
		 byte[] read = {};
         try {
             read = serialPort.readBytes();
             
             // 수신 바이트값을 읽으면 중복해서 수신되기 때문에 5개의 데이터값을 저장할 변수 선언 
             if (read != null && read.length >= 5) {
             	ArrayList<Integer> arrays = new ArrayList<>();
             	
                 for(int i=0; i<5; i++) { // hex -> dec
                     arrays.add((int)read[i]);
                 }
                 
                System.out.println(String.format("%02X", arrays.get(0)));
                System.out.println(String.format("%02X", arrays.get(1)));
                System.out.println(String.format("%02X", arrays.get(2)));
                System.out.println(String.format("%02X", arrays.get(3)));
                System.out.println(String.format("%02X", arrays.get(4)));
                
                 // $me! 
                 if ((arrays.get(0) == 36) && (arrays.get(1) == 109) && (arrays.get(2) == 101)) {
                	 System.out.println("배출기 정상 연결 ");
                	 EJECTOR_CONN = true;
//                 	System.out.println(arrays.get(0));
//                 	System.out.println(arrays.get(1));
//                 	System.out.println(arrays.get(2));
//                 	System.out.println(arrays.get(3));
//                 	System.out.println(arrays.get(4));
                 }
             }
         } catch (Exception e) {
        	 System.out.println("카드 배출기 에러입니다");
        	 e.printStackTrace();
         }
		   // TODO : Test End
	    }
	
}
