package application.util;

public class CardEjectorUtil {

}
