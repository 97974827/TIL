package application.util;

import java.util.HashMap;
import java.util.Map;

import application.Main;
import application.view.ChargePage3Controller;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;

// [카드 리더기 관련]
public class RFIDUtil {
	
	public boolean RFID_CONN = false;  			// 리더기 연결 상태
	public boolean RFID_THREAD_STATE = true;	// 리더기 스레드 상태
	public static int RFID_FLAG = 3; // 1: 충전, 2:발급, 3:조회, 4:초기화
	
	public Acr1281.CHIP_TYPE currentChipType = Acr1281.CHIP_TYPE.UNKNOWN; // 카드 칩셋 
    public PcscReader pcscReader;			// connect 관련 
    public MifareClassic mifareClassic; 	// 카드정보 관련  - 블록 조회, 업데이트 
    public Acr1281 acr1281;   // 리더기 - 카드 로드키, 인증 
	
    private DataBaseUtil dataBase = new DataBaseUtil();
	private Map<Long, String> crc_data = dataBase.getCrcData();
	private Map<String, String> config_data = dataBase.getConfigData();
	private String manager_encrypt = config_data.get("encrypt");  // DB - 카드 암호화 여부
	
	public static int MONEY = 0; 		// 현재 잔액
	public static int TOTAL_MONEY = 0;  // 총 충전금액   
	
	public boolean state_lookup = false; // 잔액조회 카드 체크 플래그
	public boolean state_charge = false; // 충전 카드 체크 플래그
	public boolean state_issued = false; // 발급 카드 체크 플래그
	
	public static void main(String[] args) {
//		RFIDUtil rf = new RFIDUtil();
		
	}
	
	public RFIDUtil() {
//		RFID_CONN = true;
//		RFID_FLAG = 3;
		
//		while(true){
//			handleReader();
//			try { Thread.sleep(2500); } catch (Exception e) { e.printStackTrace(); }
//		}
		// TODO : Test
	}
	
	public void stopReader() {
		RFID_THREAD_STATE = true;
	}
	

	public void closeReader() {
		try {
			System.out.println("closeReader");
			if(acr1281.getPcscConnection().isConnectionActive()) {	
				acr1281.getPcscConnection().disconnect();
			}
		} catch (Exception e) {
			System.out.println("closeReader Err >> " + e);
			e.printStackTrace();
		}
	}
	
	// 카드리더기 스레드 핸들링  : RFID_FLAG 설정해서 해당 메서드 실행 
	public void handleReader() {
		RFID_THREAD_STATE = false;
		Thread thread = new Thread() {
			@Override
			public void run() {	
				while (!RFID_THREAD_STATE) {
					try {
						System.out.println("RF Flag : " + RFID_FLAG);
						if(RFID_FLAG == 3) {
							readCard();
						} else {
							chargeCard();
						}
						Thread.sleep(1000);
					} catch(Exception e) {
						System.out.println("RF리더기 스레드 에러 >> " + e);
						
//						e.printStackTrace();
					}
				}
			}
		};
		thread.setDaemon(true);
		thread.start();
	}
	
	// 신버전 체크섬 검사 (바이너리 crc 블록과 계산된 crc값 비교해서 true/false 반환)
	public boolean cardCheckSum(String serial_number, int remain_money, String money_crc, String shop_id_block, String shopid_crc) {
		long int_serial_number = Long.parseLong(serial_number, 16);
		int money = 0;
		money = remain_money / 1000;
		long s = 0;
		s = int_serial_number + money;
		long money_idx = (s % 100) + 1; // DB에서 가져올 땐 +1
		
		String compare_money_crc = crc_data.get(money_idx);
		
		System.out.println(money_crc);
		System.out.println(compare_money_crc);
		
		int int_shop_id = Integer.parseInt(shop_id_block, 16);
		long compare = int_serial_number + int_shop_id;
		long shop_idx = (compare % 100) + 1;
		
		String compare_shop_crc = crc_data.get(shop_idx);
		
		System.out.println(shopid_crc);
		System.out.println(compare_shop_crc);
		
		if (money_crc.equals(compare_money_crc) && shopid_crc.equals(compare_shop_crc)) {
			return true;
		} else {
			return false;
		}
	}
	
	// 문자열이 정수인지 판별
	public static boolean isStringDouble(String s) {
		try {
			//System.out.print(s+"는 : ");
			Double.parseDouble(s);
			return true;
	    } catch (NumberFormatException e) {
		    return false;
	    }
	}
	
	public String byteAsString(byte[] data, boolean spaceinbetween){
		String tmpStr = "";

		if(data == null)
			return "";

		for (int i = 0; i < data.length; i++)
			tmpStr += String.format((spaceinbetween ? "%02X " : "%02X"), data[i]);

		return tmpStr;
	}
	
	// 마스터 체크섬 검사 
	public boolean masterCheckSum(String serial_number, String master_key_value, String master_crc) {
	
		long int_serial_number = Long.parseLong(serial_number, 16);
		int int_master_value = Integer.parseInt(master_key_value, 16);
		
		int master = (int) int_serial_number + int_master_value;
		int master_idx = master % 100 + 1;
		System.out.println(master_idx);
		String compare_master_crc = crc_data.get(master_idx);
		
		System.out.println(master_crc);
		System.out.println(compare_master_crc);
	
		if (master_crc.equals(compare_master_crc)) {
			return true;
		} else {
			return false;
		}
	}
	
	// 블록 업데이트 반환
	public byte[] encryptCharge(String money_block, String serial_number, String shopid_block) {
		
		if (RFID_FLAG == 4) {
			money_block = "00000000";
		}
		
		byte[] update_block = new byte[16];
		Long compare_result = Long.parseLong(money_block, 16) / 1000;
	    Long compare_money = compare_result + Long.parseLong(serial_number, 16);
        Long crc_index = (compare_money % 100) + 1;

        Long shop_total = Long.parseLong(serial_number, 16) + Integer.valueOf(shopid_block, 16);
        Long shop_crc_index = (shop_total % 100) + 1;
        
//        System.out.println(crc_index);
//        System.out.println(crc_data.get(crc_index));
        update_block[0] = (byte)((Integer)Integer.parseInt(money_block.substring(4, 6), 16)).byteValue();
        update_block[1] = (byte)((Integer)Integer.parseInt(money_block.substring(6, 8), 16)).byteValue();
        update_block[2] = (byte)((Integer)Integer.parseInt(money_block.substring(2, 4), 16)).byteValue();
        update_block[3] = (byte)((Integer)Integer.parseInt(money_block.substring(0, 2), 16)).byteValue();
        
        if (RFID_FLAG == 4) {
	        update_block[0] = (byte) 0x00;
	        update_block[1] = (byte) 0x00;
	        update_block[2] = (byte) 0x00;
	        update_block[3] = (byte) 0x00;
		}
        
        update_block[4] = (byte)((Integer)Integer.parseInt(crc_data.get(crc_index), 16)).byteValue();
        update_block[5] = (byte) 0x00;
        update_block[6] = (byte) 0x00;
        update_block[7] = (byte) 0x00;
        update_block[8] = (byte) 0xAA;
        update_block[9] = (byte) 0x55;
        update_block[10] = (byte)((Integer)Integer.parseInt(config_data.get("manager_no"), 16)).byteValue();
        update_block[11] = (byte) 0x00;
        update_block[12] = (byte) 0x00;
        update_block[13] = (byte)((Integer)Integer.parseInt(crc_data.get(shop_crc_index), 16)).byteValue();
        update_block[14] = (byte)((Integer)Integer.parseInt(shopid_block.substring(0, 2), 16)).byteValue();
        update_block[15] = (byte)((Integer)Integer.parseInt(shopid_block.substring(2, 4), 16)).byteValue();
        
        // 업데이트 블록  
        System.out.println("블록 업데이트 :::");
        System.out.print(byteAsString(update_block, true));
        
		return update_block;
	}
	
	// 바이트 반전값 반환
	public byte getXor(String s) {
        byte c;
        byte a = (byte)((Integer)Integer.parseInt(s, 16)).byteValue();
        byte b = (byte) 0xFF;

        c = (byte) (a ^ b);

        return c;
    }
	
	// 구버전 블록 업데이트 반환
	public byte[] commonCharge(String money_block, String shopid_block) {
		byte[] update_block = new byte[16];
		
		if (RFID_FLAG == 4) {
			money_block = "00000000";
		}
		
		
		update_block[0] = (byte)((Integer)Integer.parseInt(money_block.substring(4, 6), 16)).byteValue();
        update_block[1] = (byte)((Integer)Integer.parseInt(money_block.substring(6, 8), 16)).byteValue();
        update_block[2] = (byte)((Integer)Integer.parseInt(money_block.substring(2, 4), 16)).byteValue();
        update_block[3] = (byte)((Integer)Integer.parseInt(money_block.substring(0, 2), 16)).byteValue();
        
        if (RFID_FLAG == 4) {
        	update_block[0] = 0x00;
            update_block[1] = 0x00;
            update_block[2] = 0x00;
            update_block[3] = 0x00;
        }
        
        update_block[4] = (byte) getXor(money_block.substring(4, 6));
        update_block[5] = (byte) getXor(money_block.substring(6, 8));
        update_block[6] = (byte) getXor(money_block.substring(2, 4));
        update_block[7] = (byte) getXor(money_block.substring(0, 2));
        update_block[8] = (byte) 0xAA;
        update_block[9] = (byte) 0x55;
        update_block[10] = (byte) 0x00;
        update_block[11] = (byte) 0x00;
        update_block[12] = (byte) getXor(shopid_block.substring(0, 2));
        update_block[13] = (byte) getXor(shopid_block.substring(2, 4));
        update_block[14] = (byte)((Integer)Integer.parseInt(shopid_block.substring(0, 2), 16)).byteValue();
        update_block[15] = (byte)((Integer)Integer.parseInt(shopid_block.substring(2, 4), 16)).byteValue();
		
		return update_block;
	}
	
	// 잔액 조회
	public void readCard() {
//		System.out.println("read card");
		pcscReader = new PcscReader(); // instantiate an event handler object
    	pcscReader.setEventHandler(new ReaderEvents());
    	acr1281 = new Acr1281(pcscReader); 
    	ReaderUtil ru = new ReaderUtil();
    	String[] readerList = null;
    	
    	try {
    		readerList = acr1281.getPcscConnection().listTerminals();
    		
    		if (readerList.length == 0) {
    			System.out.println("리더기 없음");
    			RFID_CONN = false;

    		} else {
    			RFID_CONN = true;
    			
    			String rdrcon;
    			String serial_number;
    			
    			rdrcon = (String) readerList[0]; // 리더기 순서 
    			
    			acr1281.getPcscConnection().connect(rdrcon, "*");  // 리더기 컨넥트
				mifareClassic = new MifareClassic(acr1281.getPcscConnection());
				
				currentChipType = acr1281.getChipType();
				System.out.println(currentChipType);
				serial_number = mifareClassic.readSerialNumber();
				
				// 로드키
				byte[] key = new byte[6];
				byte keyNumber;
				String manager_id = dataBase.getConfigData().get("manager_id");
				System.out.println("로드 키 >>>>>>> " + manager_id);
				keyNumber = (byte)((Integer)Integer.parseInt("0", 16)).byteValue();
				key[0] = (byte)((Integer)Integer.parseInt(manager_id.substring(0,2), 16)).byteValue();
				key[1] = (byte)((Integer)Integer.parseInt(manager_id.substring(2,4), 16)).byteValue();
                key[2] = (byte)((Integer)Integer.parseInt(manager_id.substring(4,6), 16)).byteValue();
                key[3] = (byte)((Integer)Integer.parseInt(manager_id.substring(6,8), 16)).byteValue();
                key[4] = (byte)((Integer)Integer.parseInt(manager_id.substring(8,10), 16)).byteValue();
                key[5] = (byte)((Integer)Integer.parseInt(manager_id.substring(10,12), 16)).byteValue();				

                
                if(acr1281.loadAuthKey(keyNumber, key) == false) {
                	System.out.println("키 로드 실패!");
	                ru.buzzer_handle(1);
					ru.buzzer_handle(1);
					closeReader();
					return;
                }
    			
                // 인증
                byte blockNumber;
                String keyAddr = "";
    			keyNumber = 0x20;
    			Acr1281.KEYTYPES keyType = Acr1281.KEYTYPES.ACR1281_KEYTYPE_A;
                
    		    keyNumber = (byte)((Integer)Integer.parseInt("00", 16)).byteValue();
                if(keyNumber > (byte) 0x01)
                {
                    keyAddr = "01";
                    return;
                }
                if (manager_encrypt.equals("1")) {
                	blockNumber = Byte.parseByte("2");
                } else {
                	blockNumber = Byte.parseByte("1");
                }
    			
    			if(acr1281.authenticate(blockNumber, keyType, keyNumber) == false) {
    				System.out.println("인증 실패!");
    				ru.buzzer_handle(1);
    				ru.buzzer_handle(1);
    				closeReader();
    				return;
    			}
    			
    			// Read Binary Block
//    			int blockNumber;
    			int length = 16; 
    			byte[] tempStr;  // 1번지 바이너리 블록
    			byte[] tempStr2; // 2번지 바이너리 블록
    			
    			// 금액 저장번지 블록 
    			String money_block_1 = "";  
    			String money_block_2 = "";
    			String money_block_3 = "";
    			String money_block_4 = "";
    			String money_crc = "";
    			
    			// 매장 ID 저장블록
    			String shopid_crc = "";
    			String shopid_block_1 = "";
    			String shopid_block_2 = "";
											
    			tempStr2 = mifareClassic.readBinaryBlock((byte)blockNumber, (byte)length);
				
				System.out.println("********************************************************");
				System.out.println("2번지 바이너리 블록 :::");
				
				for(int i=0; i<tempStr2.length; i++) {
					System.out.print(String.format("%02X", tempStr2[i]) + " ");
					if(i==0) {
						money_block_1 = String.format("%02X", tempStr2[i]);
					}
					if (i==1) {
						money_block_2 = String.format("%02X", tempStr2[i]);
					}
					if (i==2) {
						money_block_3 = String.format("%02X", tempStr2[i]);
					}
					if (i==3) {
						money_block_4 = String.format("%02X", tempStr2[i]);
					}
					if (i==4) {
						money_crc = String.format("%02X", tempStr2[i]);
					}
					if (i==13) {
						shopid_crc = String.format("%02X", tempStr2[i]);
					}
					if (i==14) {
						shopid_block_1 = String.format("%02X", tempStr2[i]);
					}
					if (i==15) {
						shopid_block_2 = String.format("%02X", tempStr2[i]);
					}
				}
				
				System.out.println();
				
				// 매장 ID 검사
				String shop_id = shopid_block_1 + shopid_block_2;
				
				if (!shop_id.equals(dataBase.getConfigData().get("id"))){
					System.out.println("매장 ID 인증실패!");
    				ru.buzzer_handle(1);
    				ru.buzzer_handle(1);
    				closeReader();
    				return;
				}
				
				String sum_money_block = money_block_4 + money_block_3 + money_block_1 + money_block_2; 
				System.out.println(sum_money_block);
				int remain_money = Integer.parseInt(sum_money_block, 16); // 잔액
				
				if(manager_encrypt.equals("1")) {
					if (!cardCheckSum(serial_number, remain_money, money_crc, shop_id, shopid_crc)) { // 카드번호, 잔액, 잔액 crc, 매장id블록, 매장id crc
						System.out.println("2번 체크섬 인증 실패!");
	    				ru.buzzer_handle(1);
	    				ru.buzzer_handle(1);
	    				
	    				blockNumber = Byte.parseByte("1");
	    				tempStr = mifareClassic.readBinaryBlock((byte)blockNumber, (byte)length);
	    				
	    				System.out.println("********************************************************");
	    				System.out.println("1번지 바이너리 블록 :::");
	    				
	    				for(int i=0; i<tempStr2.length; i++) {
	    					System.out.print(String.format("%02X", tempStr[i]) + " ");
	    					if(i==0) {
	    						money_block_1 = String.format("%02X", tempStr[i]);
	    					}
	    					if (i==1) {
	    						money_block_2 = String.format("%02X", tempStr[i]);
	    					}
	    					if (i==2) {
	    						money_block_3 = String.format("%02X", tempStr[i]);
	    					}
	    					if (i==3) {
	    						money_block_4 = String.format("%02X", tempStr[i]);
	    					}
	    					if (i==4) {
	    						money_crc = String.format("%02X", tempStr[i]);
	    					}
	    					if (i==13) {
	    						shopid_crc = String.format("%02X", tempStr[i]);
	    					}
	    					if (i==14) {
	    						shopid_block_1 = String.format("%02X", tempStr[i]);
	    					}
	    					if (i==15) {
	    						shopid_block_2 = String.format("%02X", tempStr[i]);
	    					}
	    				}
	    				
	    				System.out.println();
	    				
	    				// 매장 ID 검사
	    				shop_id = shopid_block_1 + shopid_block_2;
	    				
	    				if (!shop_id.equals(dataBase.getConfigData().get("id"))){
	    					System.out.println("매장 ID 인증실패!");
	        				ru.buzzer_handle(1);
	        				ru.buzzer_handle(1);
	        				closeReader();
	        				return;
	    				}
	    				
	    				sum_money_block = money_block_4 + money_block_3 + money_block_1 + money_block_2; 
	    				System.out.println(sum_money_block);
	    				remain_money = Integer.parseInt(sum_money_block, 16); // 잔액
	    				
	    				crc_data = dataBase.getCrcData(); // DB crc data
	    				manager_encrypt = dataBase.getConfigData().get("encrypt"); // DB 암호화 여부 
	    				
	    				
	    				if(manager_encrypt.equals("1")) {
	    					if (!cardCheckSum(serial_number, remain_money, money_crc, shop_id, shopid_crc)) { // 카드번호, 잔액, 잔액 crc, 매장id블록, 매장id crc
	    						System.out.println("1번지 체크섬 인증 실패!");
	    	    				ru.buzzer_handle(1);
	    	    				ru.buzzer_handle(1);
	    	    				return;
	    					}
	    				}
					}
				
					System.out.println("현재 잔액 : " + String.format("%,d", remain_money) + " 원");
					ru.buzzer_handle(10);
					MONEY = remain_money;
					System.out.println("전달할 변수 : " + MONEY);
					state_lookup = true;
					mifareClassic.buzzer_control();
					closeReader();
					
				} // 암호화 플로우 끝
				
    		}
    		
    	} catch (Exception e) {
    		System.out.println("Read Card Thread Error >> " + e);
    		if(e.getMessage().equals("list() failed") || e.getMessage().equals("SCARD_E_NOT_TRANSACTED")) {
    			isReadFail(e.getMessage());
    		}
    	}
	}
	
	// 카드 충전 / 발급 
	public void chargeCard() {
//		System.out.println("charge card");
		pcscReader = new PcscReader(); // instantiate an event handler object
    	pcscReader.setEventHandler(new ReaderEvents());
    	//pcscReader.getEventHandler().addEventListener(this);
    	acr1281 = new Acr1281(pcscReader); 
    	ReaderUtil ru = new ReaderUtil();
    	String[] readerList = null;
    	
    	try {
    		readerList = acr1281.getPcscConnection().listTerminals();

    		if (readerList.length == 0) {
    			System.out.println("리더기 없음");
    			RFID_CONN = false;

    		} else {
    			RFID_CONN = true;
    			
    			String rdrcon;
    			String rdrcon2;
    			String serial_number; // 카드 시리얼 번호 
    			
    			rdrcon = (String) readerList[0];  // 충전 리더기 
    			rdrcon2 = (String) readerList[1]; // 발급 리더기 
				
    			// 충전 
    			if (Main.RFID.RFID_FLAG == 1) {
				
    				System.out.println("###############################   충전    ##############################");
    				System.out.println(rdrcon);
	    			acr1281.getPcscConnection().connect(rdrcon, "*");  // 리더기 컨넥트
					mifareClassic = new MifareClassic(acr1281.getPcscConnection());
					
					currentChipType = acr1281.getChipType();
					System.out.println(currentChipType);
					serial_number = mifareClassic.readSerialNumber();
					System.out.println("카드번호 : " + serial_number);
					// 로드키
					byte[] key = new byte[6];
					byte keyNumber;
					String db_manager_id = dataBase.getConfigData().get("manager_id"); // 디비 카드 핀코드 
	
					keyNumber = (byte)((Integer)Integer.parseInt("1", 16)).byteValue();
					key[0] = (byte)((Integer)Integer.parseInt(db_manager_id.substring(0,2), 16)).byteValue();
					key[1] = (byte)((Integer)Integer.parseInt(db_manager_id.substring(2,4), 16)).byteValue();
	                key[2] = (byte)((Integer)Integer.parseInt(db_manager_id.substring(4,6), 16)).byteValue();
	                key[3] = (byte)((Integer)Integer.parseInt(db_manager_id.substring(6,8), 16)).byteValue();
	                key[4] = (byte)((Integer)Integer.parseInt(db_manager_id.substring(8,10), 16)).byteValue();
	                key[5] = (byte)((Integer)Integer.parseInt(db_manager_id.substring(10,12), 16)).byteValue();				
	
	                
	                if(acr1281.loadAuthKey(keyNumber, key) == false) {
	                	System.out.println("키 로드 실패!");
		                ru.buzzer_handle(1);
						ru.buzzer_handle(1);
						closeReader();
	    				return;
	                }
	                // 인증
	                byte blockNumber; // 카드 저장번지 
	                String keyAddr = "";
	    			keyNumber = 0x20;
	    			Acr1281.KEYTYPES keyType = Acr1281.KEYTYPES.ACR1281_KEYTYPE_A;
	                
	    		    keyNumber = (byte)((Integer)Integer.parseInt("01", 16)).byteValue();
	                if(keyNumber > (byte) 0x01)
	                {
	                    keyAddr = "01";
	                    return;
	                }
	                if (manager_encrypt.equals("1")) {
	                	blockNumber = Byte.parseByte("2");
	                } else {
	                	blockNumber = Byte.parseByte("1");
	                }
	    			
	    			if(acr1281.authenticate(blockNumber, keyType, keyNumber) == false) {
	    				System.out.println("인증 실패!");
	    				ru.buzzer_handle(1);
	    				ru.buzzer_handle(1);
	    				closeReader();
	    				return;
	    			}
	    			
	    			// Read Binary Block
	//    			int blockNumber;
	    			int length = 16; 
	    			byte[] tempStr;  // 1번지 바이너리 블록
	    			byte[] tempStr2; // 2번지 바이너리 블록 
	    			
	    			// 금액 저장번지 블록 
	    			String money_block_1 = "";  
	    			String money_block_2 = "";
	    			String money_block_3 = "";
	    			String money_block_4 = "";
	    			String money_crc = "";
	    			
	    			// 매장 ID 저장블록
	    			String shopid_crc = "";
	    			String shopid_block_1 = "";
	    			String shopid_block_2 = "";
	    			
	    			String manager_id_block = "";
	    			String master_key_block = "";
	    			String master_crc = "";
	    			
	    			
	    			tempStr2 = mifareClassic.readBinaryBlock((byte)blockNumber, (byte)length);
					
					System.out.println("********************************************************");
					System.out.println("2번지 바이너리 블록 :::");
					
					for(int i=0; i<tempStr2.length; i++) {
						System.out.print(String.format("%02X", tempStr2[i]) + " ");
						if (i==0) {
							money_block_1 = String.format("%02X", tempStr2[i]);
						}
						if (i==1) {
							money_block_2 = String.format("%02X", tempStr2[i]);
						}
						if (i==2) {
							money_block_3 = String.format("%02X", tempStr2[i]);
						}
						if (i==3) {
							money_block_4 = String.format("%02X", tempStr2[i]);
						}
						if (i==4) {
							money_crc = String.format("%02X", tempStr2[i]);
						}
						if (i==10) {
							manager_id_block = String.format("%02X", tempStr2[i]);
						}
						if (i==11) {
							master_key_block = String.format("%02X", tempStr2[i]);
						}
						if (i==12) {
							master_crc = String.format("%02X", tempStr2[i]);
						}
						if (i==13) {
							shopid_crc = String.format("%02X", tempStr2[i]);
						}
						if (i==14) {
							shopid_block_1 = String.format("%02X", tempStr2[i]);
						}
						if (i==15) {
							shopid_block_2 = String.format("%02X", tempStr2[i]);
						}
					}
					
					System.out.println();
					
					// 매장 ID 검사
					String shop_id = shopid_block_1 + shopid_block_2;
					
					if (!shop_id.equals(dataBase.getConfigData().get("id"))){
						System.out.println("매장 ID 인증실패!");
	    				ru.buzzer_handle(1);
	    				ru.buzzer_handle(1);
	    				closeReader();
	    				return;
					}
					
					// 마스터 카드인지 검사
					if(master_key_block.equals("0B")) {
						System.out.println("마스터 카드 입니다");
						// 마스터 체크섬 검사 
						masterCheckSum(serial_number, master_key_block, master_crc);
						ru.buzzer_handle(10);
						closeReader();
	    				return;
					}
					
					String sum_money_block = money_block_4 + money_block_3 + money_block_1 + money_block_2; 
					System.out.println(sum_money_block);
					int remain_money = Integer.parseInt(sum_money_block, 16); // 잔액
					
	//				crc_data = dataBase.getCrcMapData(); // DB crc data
					//String manager_encrypt = dataBase.getConfigData().get("encrypt"); // DB 암호화 여부 
					
					// 암호화 카드일때
					if(manager_encrypt.equals("1")) {
						if (!cardCheckSum(serial_number, remain_money, money_crc, shop_id, shopid_crc)) { // 카드번호, 잔액, 잔액 crc, 매장id블록, 매장id crc
							System.out.println("2번지 체크섬 인증실패!");
		    				ru.buzzer_handle(1);
		    				ru.buzzer_handle(1);
		        			/*
		    				blockNumber = Byte.parseByte("1");
		    				tempStr = mifareClassic.readBinaryBlock((byte)blockNumber, (byte)length);
		    				
		    				System.out.println("********************************************************");
		    				System.out.println("1번지 바이너리 블록 :::");
		    				
		    				for(int i=0; i<tempStr.length; i++) {
		    					System.out.print(String.format("%02X", tempStr[i]) + " ");
		    					if (i==0) {
		    						money_block_1 = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==1) {
		    						money_block_2 = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==2) {
		    						money_block_3 = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==3) {
		    						money_block_4 = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==4) {
		    						money_crc = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==10) {
		    						manager_id_block = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==11) {
		    						master_key_block = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==12) {
		    						master_crc = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==13) {
		    						shopid_crc = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==14) {
		    						shopid_block_1 = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==15) {
		    						shopid_block_2 = String.format("%02X", tempStr[i]);
		    					}
		    				}
		    				
		    				System.out.println();
		    				
		    				// 매장 ID 검사
		    				shop_id = shopid_block_1 + shopid_block_2;
		    				
		    				if (!shop_id.equals(dataBase.getConfigData().get("id"))){
		    					System.out.println("매장 ID 인증실패!");
		        				ru.buzzer_handle(1);
		        				ru.buzzer_handle(1);
		        				closeReader();
		        				return;
		    				}
		    				
		    				// 마스터 카드인지 검사
		    				if(master_key_block.equals("0B")) {
		    					System.out.println("마스터 카드 입니다");
		    					// 마스터 체크섬 검사 
		    					masterCheckSum(serial_number, master_key_block, master_crc);
		    					ru.buzzer_handle(10);
		        				closeReader();
		        				return;
		    				}
		    				
		    				sum_money_block = money_block_4 + money_block_3 + money_block_1 + money_block_2; 
		    				System.out.println(sum_money_block);
		    				remain_money = Integer.parseInt(sum_money_block, 16); // 잔액
		    				
	//	    				crc_data = dataBase.getCrcMapData(); // DB crc data
		    				//String manager_encrypt = dataBase.getConfigData().get("encrypt"); // DB 암호화 여부 
		    				
		    				if(manager_encrypt.equals("1")) {
		    					if (!cardCheckSum(serial_number, remain_money, money_crc, shop_id, shopid_crc)) { // 카드번호, 잔액, 잔액 crc, 매장id블록, 매장id crc
		    						System.out.println("1번지 체크섬 인증실패!");
		    						System.out.println("충전 실패 ");
		    	    				ru.buzzer_handle(1);
		    	    				ru.buzzer_handle(1);
				    				closeReader();
				    				return;
		    					}
		    				}*/
						} // TODO : 암호화 체크섬 맞지않을때 1번지 검사 끝
						 
					}
					
					System.out.println("현재 잔액 : " + String.format("%,d", remain_money) + " 원");
					System.out.println("충전 금액 : " + String.format("%,d", Main.bill.getBillTotalMoney()) + " 원");
					
					// 카드에 맞게 충전하기 : 현재잔액  + (투입금액+보너스) = 총 충전금액 
					int sum = remain_money + Main.bill.getBillTotalMoney();
					System.out.println("총 금액 : " + String.format("%,d", sum) + " 원");
					String charge_money = String.format("%08X", sum); // 총 충전금액 
					
					if (manager_encrypt.equals("1")) {
						tempStr = encryptCharge(charge_money, serial_number, shop_id);
						tempStr2 = encryptCharge(charge_money, serial_number, shop_id);
						
					} else {
						tempStr = commonCharge(charge_money, shop_id);
					}
					
					// TODO : 1,2 번지 백업 해야함 
					if (mifareClassic.updateBinaryBlock((byte)blockNumber, tempStr2, (byte)length)) {
						System.out.println("\n2번지 업데이트 성공");
						ru.buzzer_handle(10);
						
					} else {
						blockNumber = Byte.parseByte("1");
					
						if (mifareClassic.updateBinaryBlock((byte)blockNumber, tempStr, (byte)length)) {
							System.out.println("\n1번지 업데이트 성공");
							ru.buzzer_handle(10);
						} else {
							System.out.println("업데이트 실패 ");
							ru.buzzer_handle(1);
		    				ru.buzzer_handle(1);
		    				closeReader();
							return;
						}
					}
					
					state_charge = true;
					TOTAL_MONEY = sum;
					Main.dataBase.setChargeData(serial_number, remain_money); // DB 저장
					stopReader(); // 리더기 스레드 중지
					closeReader();
					
	    		} 
    			
    			// 발급
    			else if (Main.RFID.RFID_FLAG == 2){
    				System.out.println("###############################   발 급   ##############################");
    				System.out.println(rdrcon2);
    				acr1281.getPcscConnection().connect(rdrcon2, "*");  // 리더기 컨넥트
    				mifareClassic = new MifareClassic(acr1281.getPcscConnection());
					
					currentChipType = acr1281.getChipType();
					System.out.println(currentChipType);
					serial_number = mifareClassic.readSerialNumber();
					System.out.println("카드번호 : " + serial_number);
					// 로드키
					byte[] key = new byte[6];
					byte keyNumber;
					String db_manager_id = dataBase.getConfigData().get("manager_id"); // 디비 카드 핀코드 
	
					keyNumber = (byte)((Integer)Integer.parseInt("1", 16)).byteValue();
					key[0] = (byte)((Integer)Integer.parseInt(db_manager_id.substring(0,2), 16)).byteValue();
					key[1] = (byte)((Integer)Integer.parseInt(db_manager_id.substring(2,4), 16)).byteValue();
	                key[2] = (byte)((Integer)Integer.parseInt(db_manager_id.substring(4,6), 16)).byteValue();
	                key[3] = (byte)((Integer)Integer.parseInt(db_manager_id.substring(6,8), 16)).byteValue();
	                key[4] = (byte)((Integer)Integer.parseInt(db_manager_id.substring(8,10), 16)).byteValue();
	                key[5] = (byte)((Integer)Integer.parseInt(db_manager_id.substring(10,12), 16)).byteValue();				
	
	                
	                if(acr1281.loadAuthKey(keyNumber, key) == false) {
	                	System.out.println("키 로드 실패!");
		                ru.buzzer_handle(1);
						ru.buzzer_handle(1);
						closeReader();
	    				return;
	                }
	                // 인증
	                byte blockNumber; // 카드 저장번지 
	                String keyAddr = "";
	    			keyNumber = 0x20;
	    			Acr1281.KEYTYPES keyType = Acr1281.KEYTYPES.ACR1281_KEYTYPE_A;
	                
	    		    keyNumber = (byte)((Integer)Integer.parseInt("01", 16)).byteValue();
	                if(keyNumber > (byte) 0x01)
	                {
	                    keyAddr = "01";
	                    return;
	                }
	                if (manager_encrypt.equals("1")) {
	                	blockNumber = Byte.parseByte("2");
	                } else {
	                	blockNumber = Byte.parseByte("1");
	                }
	    			
	    			if(acr1281.authenticate(blockNumber, keyType, keyNumber) == false) {
	    				System.out.println("인증 실패!");
	    				ru.buzzer_handle(1);
	    				ru.buzzer_handle(1);
	    				closeReader();
	    				return;
	    			}
	    			
	    			// Read Binary Block
	//    			int blockNumber;
	    			int length = 16; 
	    			byte[] tempStr;  // 1번지 바이너리 블록
	    			byte[] tempStr2; // 2번지 바이너리 블록 
	    			
	    			// 금액 저장번지 블록 
	    			String money_block_1 = "";  
	    			String money_block_2 = "";
	    			String money_block_3 = "";
	    			String money_block_4 = "";
	    			String money_crc = "";
	    			
	    			// 매장 ID 저장블록
	    			String shopid_crc = "";
	    			String shopid_block_1 = "";
	    			String shopid_block_2 = "";
	    			
	    			String manager_id_block = "";
	    			String master_key_block = "";
	    			String master_crc = "";
	    			
	    			
	    			tempStr2 = mifareClassic.readBinaryBlock((byte)blockNumber, (byte)length);
					
					System.out.println("********************************************************");
					System.out.println("2번지 바이너리 블록 :::");
					
					for(int i=0; i<tempStr2.length; i++) {
						System.out.print(String.format("%02X", tempStr2[i]) + " ");
						if (i==0) {
							money_block_1 = String.format("%02X", tempStr2[i]);
						}
						if (i==1) {
							money_block_2 = String.format("%02X", tempStr2[i]);
						}
						if (i==2) {
							money_block_3 = String.format("%02X", tempStr2[i]);
						}
						if (i==3) {
							money_block_4 = String.format("%02X", tempStr2[i]);
						}
						if (i==4) {
							money_crc = String.format("%02X", tempStr2[i]);
						}
						if (i==10) {
							manager_id_block = String.format("%02X", tempStr2[i]);
						}
						if (i==11) {
							master_key_block = String.format("%02X", tempStr2[i]);
						}
						if (i==12) {
							master_crc = String.format("%02X", tempStr2[i]);
						}
						if (i==13) {
							shopid_crc = String.format("%02X", tempStr2[i]);
						}
						if (i==14) {
							shopid_block_1 = String.format("%02X", tempStr2[i]);
						}
						if (i==15) {
							shopid_block_2 = String.format("%02X", tempStr2[i]);
						}
					}
					
					System.out.println();
					
					// 매장 ID 검사
					String shop_id = shopid_block_1 + shopid_block_2;
					
					if (!shop_id.equals(dataBase.getConfigData().get("id"))){
						System.out.println("매장 ID 인증실패!");
	    				ru.buzzer_handle(1);
	    				ru.buzzer_handle(1);
	    				closeReader();
	    				return;
					}
					
					// 마스터 카드인지 검사
					if(master_key_block.equals("0B")) {
						System.out.println("마스터 카드 입니다");
						// 마스터 체크섬 검사 
						masterCheckSum(serial_number, master_key_block, master_crc);
						ru.buzzer_handle(10);
						closeReader();
	    				return;
					}
					
					String sum_money_block = money_block_4 + money_block_3 + money_block_1 + money_block_2; 
					System.out.println(sum_money_block);
					int remain_money = Integer.parseInt(sum_money_block, 16); // 잔액
					
	//				crc_data = dataBase.getCrcMapData(); // DB crc data
					//String manager_encrypt = dataBase.getConfigData().get("encrypt"); // DB 암호화 여부 
					
					// 암호화 카드일때
					if(manager_encrypt.equals("1")) {
						if (!cardCheckSum(serial_number, remain_money, money_crc, shop_id, shopid_crc)) { // 카드번호, 잔액, 잔액 crc, 매장id블록, 매장id crc
							System.out.println("2번지 체크섬 인증실패!");
		    				ru.buzzer_handle(1);
		    				ru.buzzer_handle(1);
		        			/*
		    				blockNumber = Byte.parseByte("1");
		    				tempStr = mifareClassic.readBinaryBlock((byte)blockNumber, (byte)length);
		    				
		    				System.out.println("********************************************************");
		    				System.out.println("1번지 바이너리 블록 :::");
		    				
		    				for(int i=0; i<tempStr.length; i++) {
		    					System.out.print(String.format("%02X", tempStr[i]) + " ");
		    					if (i==0) {
		    						money_block_1 = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==1) {
		    						money_block_2 = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==2) {
		    						money_block_3 = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==3) {
		    						money_block_4 = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==4) {
		    						money_crc = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==10) {
		    						manager_id_block = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==11) {
		    						master_key_block = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==12) {
		    						master_crc = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==13) {
		    						shopid_crc = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==14) {
		    						shopid_block_1 = String.format("%02X", tempStr[i]);
		    					}
		    					if (i==15) {
		    						shopid_block_2 = String.format("%02X", tempStr[i]);
		    					}
		    				}
		    				
		    				System.out.println();
		    				
		    				// 매장 ID 검사
		    				shop_id = shopid_block_1 + shopid_block_2;
		    				
		    				if (!shop_id.equals(dataBase.getConfigData().get("id"))){
		    					System.out.println("매장 ID 인증실패!");
		        				ru.buzzer_handle(1);
		        				ru.buzzer_handle(1);
		        				closeReader();
		        				return;
		    				}
		    				
		    				// 마스터 카드인지 검사
		    				if(master_key_block.equals("0B")) {
		    					System.out.println("마스터 카드 입니다");
		    					// 마스터 체크섬 검사 
		    					masterCheckSum(serial_number, master_key_block, master_crc);
		    					ru.buzzer_handle(10);
		        				closeReader();
		        				return;
		    				}
		    				
		    				sum_money_block = money_block_4 + money_block_3 + money_block_1 + money_block_2; 
		    				System.out.println(sum_money_block);
		    				remain_money = Integer.parseInt(sum_money_block, 16); // 잔액
		    				
	//	    				crc_data = dataBase.getCrcMapData(); // DB crc data
		    				//String manager_encrypt = dataBase.getConfigData().get("encrypt"); // DB 암호화 여부 
		    				
		    				if(manager_encrypt.equals("1")) {
		    					if (!cardCheckSum(serial_number, remain_money, money_crc, shop_id, shopid_crc)) { // 카드번호, 잔액, 잔액 crc, 매장id블록, 매장id crc
		    						System.out.println("1번지 체크섬 인증실패!");
		    						System.out.println("충전 실패 ");
		    	    				ru.buzzer_handle(1);
		    	    				ru.buzzer_handle(1);
				    				closeReader();
				    				return;
		    					}
		    				}*/
						} // TODO : 암호화 체크섬 맞지않을때 1번지 검사 끝
						 
					}
					
					int card_price = Integer.parseInt(Main.dataBase.getConfigData().get("card_price"));
					System.out.println("현재 잔액 : " + String.format("%,d", remain_money) + " 원");
					System.out.println("충전 금액 : " + String.format("%,d", Main.bill.getBillTotalMoney() - card_price) + " 원");
					
					// 카드에 맞게 충전하기 : 현재잔액  + (투입금액+보너스) - 카드금액  = 총 발급금액 
					
					Main.bill.issued_money -= card_price;
					int sum = remain_money + Main.bill.issued_money;
					System.out.println("총 금액 : " + String.format("%,d", sum) + " 원");
					String charge_money = String.format("%08X", sum); // 총 충전금액 
					
					if (manager_encrypt.equals("1")) {
						tempStr = encryptCharge(charge_money, serial_number, shop_id);
						tempStr2 = encryptCharge(charge_money, serial_number, shop_id);
					} else {
						tempStr = commonCharge(charge_money, shop_id);
					}
					
					// TODO : 1,2 번지 백업 해야함 
					if (mifareClassic.updateBinaryBlock((byte)blockNumber, tempStr2, (byte)length)) {
						System.out.println("\n2번지 업데이트 성공");
						ru.buzzer_handle(10);
						
					} else {
						blockNumber = Byte.parseByte("1");
					
						if (mifareClassic.updateBinaryBlock((byte)blockNumber, tempStr, (byte)length)) {
							System.out.println("\n1번지 업데이트 성공");
							ru.buzzer_handle(10);
						} else {
							System.out.println("업데이트 실패 ");
							ru.buzzer_handle(1);
		    				ru.buzzer_handle(1);
		    				closeReader();
							return;
						}
					}
					
					state_issued = true;
					Main.bill.issued_money = sum;
					Main.dataBase.setChargeData(serial_number, remain_money); // DB 저장
					stopReader(); // 리더기 스레드 중지 
					mifareClassic.buzzer_control();
					closeReader();
    			}
    		}
    		
    	} catch (Exception e) {
    		System.out.println("Charge Card Thread Error >> " + e);
    		if(e.getMessage().equals("list() failed") || e.getMessage().equals("SCARD_E_NOT_TRANSACTED")) {
    			isReadFail(e.getMessage());
    		}
//    		e.printStackTrace();
    	}
	}
	
	// 리더기 연결 실패 시 재연결 
	public void isReadFail(String comment) {
		switch(comment) {
		case "list() failed":
			stopReader();
			handleReader();
			break;
		case "SCARD_E_NOT_TRANSACTED":
			stopReader();
			handleReader();
			break;
		}
		
	}
	
	@FXML
	private void handleNext() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/ChargePage3.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			Main.rootLayout.setCenter(page);
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}
