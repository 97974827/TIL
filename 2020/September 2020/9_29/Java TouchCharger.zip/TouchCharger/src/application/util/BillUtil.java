package application.util;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import jssc.SerialPort;
import jssc.SerialPortList;
import java.io.File;
import java.util.ArrayList;

import application.Main;

// [지폐인식기 관련]
public class BillUtil {
	
    SerialPort serialPort;
    
    public boolean BILL_CONN = false; // 연결
    public boolean STOP = false; // 지폐인식기 활성 플래그
    
    public boolean active_stop = false; // 상태 플래그 
    public int ACTIVE_STATE;     // 상태
    
    private int BILL_DATA = 0;  // 권종
    
    private int BILL_CURRENT_MONEY = 0; // 투입금액
    private int BILL_CURRENT_BONUS = 0; // 보너스 
    
    public int USE_CURRENT_MONEY = 0; // 사용된 투임금액 
    public int USE_CURRENT_BONUS = 0; // 사용된 보너스
    
    private static int BILL_TOTAL_MONEY; // 투입금액 + 보너스  
    
    public static int issued_money; // 테스트용 발급금액
    
    public static void main(String[] args) {
//    	BillUtil bill = new BillUtil();
//		bill.writeBlock("hi");
	}
    

	public void setBillTotalMoney(int bILL_TOTAL_MONEY) {
		this.BILL_TOTAL_MONEY = bILL_TOTAL_MONEY;
	}
	
    public int getBillTotalMoney() {
		return BILL_TOTAL_MONEY;
	}

	public int getBillCurrentMoney() {
		return BILL_CURRENT_MONEY;
	}

	public void setBillCurrentMoney(int bILL_CURRENT_MONEY) {
		this.BILL_CURRENT_MONEY = bILL_CURRENT_MONEY;
	}

	public int getBillCurrentBonus() {
		return BILL_CURRENT_BONUS;
	}

	public void setBillCurrentBonus(int bILL_CURRENT_BONUS) {
		this.BILL_CURRENT_BONUS = bILL_CURRENT_BONUS;
	}
	
	/* 
	 // TODO : 단독 테스트 코드
	public BillUtil() {
    	
	    try {
	    	serialPort = new SerialPort("/dev/ttyUSB1");
	       if (!serialPort.isOpened()) {
	    	   System.out.println("Bill Serial Open");
	          serialPort.openPort();//Open serial port
	          serialPort.setParams(SerialPort.BAUDRATE_9600,
	                               SerialPort.DATABITS_8,
	                               SerialPort.STOPBITS_1,
	                               SerialPort.PARITY_NONE);
	          writeBlock("hi");
	          writeBlock("enable");
	          readBlock(); // 데이터 파악 스레드
	        }
	        while(true) {
	    	   activeStateThread(); // 지폐인식기 상태 검사 - 명령 
	          Thread.sleep(1000);
	        }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	}
	*/
	
    public BillUtil() {
        try {
//        	String[] portNames = null;
//            portNames = SerialPortList.getPortNames();
//            for (String string : portNames) {
//                System.out.println(string);
//            }
            serialPort = new SerialPort("/dev/ttyUSB1");
            if (!serialPort.isOpened()) {
            	System.out.println("Bill Serial Open");
                serialPort.openPort();//Open serial port
                serialPort.setParams(SerialPort.BAUDRATE_9600,
                        SerialPort.DATABITS_8,
                        SerialPort.STOPBITS_1,
                        SerialPort.PARITY_NONE);
        		writeBlock("hi");
//        		readBlock(); // 스레드 사용 X
        		writeBlock("enable");
                readBlock(); // 데이터 파악 스레드 
            }
            startActiveThread(); // 지폐인식기 명령 스레드 
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    
    public void closeSerial() {
    	try {
    		System.out.println("bill close");
    		if (!serialPort.isOpened()) { serialPort.closePort(); }
    	} catch(Exception e) {
    		e.printStackTrace();
    	}
    }
    
    public void readBlock() {
        Thread thread = new Thread() {
            boolean connect = false;
            
            @Override
            public void run() {
                byte[] read = {};
                
                while(true) {
                    try {
                        read = serialPort.readBytes();
//                    	for(int i=0; i<5; i++) {
//                    		read = serialPort.readBytes();
//                    	}
                        
                        // 수신 바이트값을 읽으면 중복해서 수신되기 때문에 5개의 데이터 값을 저장할 변수 선언 
                        if (read != null && read.length >= 5) {
                        	ArrayList<Integer> arrays = new ArrayList<>();
                        	
                            for(int i=0; i<5; i++) { // hex -> dec
                                arrays.add( (int) read[i]);
                            }
                            // $me! 
                            if ((arrays.get(0) == 36) && (arrays.get(1) == 109) && (arrays.get(2) == 101)) {
                            	 System.out.println(String.format("%02X", arrays.get(0)));
                                 System.out.println(String.format("%02X", arrays.get(1)));
                                 System.out.println(String.format("%02X", arrays.get(2)));
                                 System.out.println(String.format("%02X", arrays.get(3)));
                                 System.out.println(String.format("%02X", arrays.get(4)));
//                            	System.out.println(arrays.get(0));
//                            	System.out.println(arrays.get(1));
//                            	System.out.println(arrays.get(2));
//                            	System.out.println(arrays.get(3));
//                            	System.out.println(arrays.get(4));
                                BILL_CONN = true;
                            } else { // getActiveState
                                if ((arrays.get(0) == 36) && (arrays.get(1) == 103) && (arrays.get(2) == 97)){
                                    ACTIVE_STATE = arrays.get(3); // 활성 상태 전달
                                // BILL DATA
                                } else if ((arrays.get(0) == 36) && (arrays.get(1) == 0x67) && (arrays.get(2) == 0x62)) {
                                	System.out.println("Bill Data >> " + arrays.get(3));                                	
                                    BILL_DATA = arrays.get(3);
                                    
                                    switch (BILL_DATA) {
                                        case 1:
                                            BILL_CURRENT_MONEY = 1000;
                                            break;
                                        case 5:
                                            BILL_CURRENT_MONEY = 5000;
                                            break;
                                        case 10:
                                            BILL_CURRENT_MONEY = 10000;
                                            break;
                                        case 50:
                                            BILL_CURRENT_MONEY = 50000;
                                            break;
                                        default:
                                            BILL_CURRENT_MONEY = 0;
                                            BILL_CURRENT_BONUS = 0;
                                            break;
                                    }

                                    if (BILL_CURRENT_MONEY > 0) {
                                    	try {
                                    		Main.mp.stop();
                                    	} catch (NullPointerException e) {}
                                    	
                                        String path = new File("msgs/msg022.wav").getAbsolutePath();
                                        Main.me = new Media(new File(path).toURI().toString());
                                        Main.mp = new MediaPlayer(Main.me);
                                        Main.mp.play();
                                    }
                                  
                                    USE_CURRENT_MONEY += BILL_CURRENT_MONEY;
                                    
                                    if ( USE_CURRENT_MONEY >= 10000 && USE_CURRENT_MONEY < 20000) {
                                    	BILL_CURRENT_BONUS += Integer.parseInt(Main.dataBase.getConfigData().get("bonus1"));
                                    	
                                    } else if ( USE_CURRENT_MONEY >= 20000 && USE_CURRENT_MONEY < 30000) {
                                    	BILL_CURRENT_BONUS += Integer.parseInt(Main.dataBase.getConfigData().get("bonus2"));
                                    	
                                    } else if ( USE_CURRENT_MONEY >= 30000 && USE_CURRENT_MONEY < 40000) {
                                    	BILL_CURRENT_BONUS += Integer.parseInt(Main.dataBase.getConfigData().get("bonus3"));
                                    	
                                    } else if ( USE_CURRENT_MONEY >= 40000 && USE_CURRENT_MONEY < 50000) {
                                    	BILL_CURRENT_BONUS += Integer.parseInt(Main.dataBase.getConfigData().get("bonus4"));
                                    	
                                    } else if ( USE_CURRENT_MONEY >= 50000 && USE_CURRENT_MONEY < 60000) {
                                    	BILL_CURRENT_BONUS += Integer.parseInt(Main.dataBase.getConfigData().get("bonus5"));
                                    	
                                    } else if ( USE_CURRENT_MONEY >= 60000 && USE_CURRENT_MONEY < 70000) {
                                    	BILL_CURRENT_BONUS += Integer.parseInt(Main.dataBase.getConfigData().get("bonus6"));
                                    	
                                    } else if ( USE_CURRENT_MONEY >= 70000 && USE_CURRENT_MONEY < 80000) {
                                    	BILL_CURRENT_BONUS += Integer.parseInt(Main.dataBase.getConfigData().get("bonus7"));
                                    	
                                    } else if ( USE_CURRENT_MONEY >= 80000 && USE_CURRENT_MONEY < 90000) {
                                    	BILL_CURRENT_BONUS += Integer.parseInt(Main.dataBase.getConfigData().get("bonus8"));
                                    	
                                    } else if ( USE_CURRENT_MONEY >= 90000 && USE_CURRENT_MONEY < 100000) {
                                    	BILL_CURRENT_BONUS += Integer.parseInt(Main.dataBase.getConfigData().get("bonus9"));
                                    	
                                    } else if ( USE_CURRENT_MONEY >= 100000 ) {
                                    	BILL_CURRENT_BONUS += Integer.parseInt(Main.dataBase.getConfigData().get("bonus10"));
                                    	
                                    } else {
                                    	System.out.println("보너스 없음 ");
                                    }
                                    
//                                    if(USE_CURRENT_MONEY%100000!=0) // TODO 10만원이상 보너스 초기화 해결하기 
                                    if (USE_CURRENT_MONEY >= 10000 && USE_CURRENT_MONEY < 100000){
                                    	BILL_CURRENT_BONUS = 0; // 보너스 초기화
                                    }
                                    USE_CURRENT_BONUS = BILL_CURRENT_BONUS; // 뷰에 보여질 보너스 
                                    BILL_TOTAL_MONEY = (USE_CURRENT_MONEY + USE_CURRENT_BONUS);
                                    
                                    issued_money = BILL_TOTAL_MONEY; // 발급 금액 따로 저장  
                                    System.out.println("BILL_CURRENT_MONEY : " + BILL_CURRENT_MONEY);
                                    System.out.println("BILL_CURRENT_BONUS : " + BILL_CURRENT_BONUS);
                                    System.out.println("USE_CURRENT_MONEY  : " + USE_CURRENT_MONEY);
                                    System.out.println("USE_CURRENT_BONUS  : " + USE_CURRENT_BONUS);
                                    System.out.println("BILL_TOTAL_MONEY   : " + BILL_TOTAL_MONEY);
                                    
                                }
                            }
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        BILL_CONN = false;
                    }

                    try {Thread.sleep(100);} catch (Exception e){}
                }
            }
        };
        //thread.setPriority(4);
        thread.setDaemon(true);
        thread.start();
    }

    public void writeBlock(String command) {
    	System.out.println("write block : " + command);
        byte[] buff = new byte[5];
        switch (command) {
            case "hi":
                buff[0] = (byte) 0x24;
                buff[1] = (byte) 0x48;
                buff[2] = (byte) 0x69;
                buff[3] = (byte) 0x3f;
                buff[4] = (byte) 0xf0;
                break;

            case "enable":
                buff[0] = (byte) 0x24;
                buff[1] = (byte) 0x53;
                buff[2] = (byte) 0x41;
                buff[3] = (byte) 0x0D;
                buff[4] = (byte) 0xA1;
                break;

            case "disable":
                buff[0] = (byte) 0x24;
                buff[1] = (byte) 0x53;
                buff[2] = (byte) 0x41;
                buff[3] = (byte) 0x0E;
                buff[4] = (byte) 0xA2;
                break;

            case "bill_data":
                buff[0] = (byte) 0x24;
                buff[1] = (byte) 0x47;
                buff[2] = (byte) 0x42;
                buff[3] = (byte) 0x3f;
                buff[4] = (byte) 0xc8;
                break;

            case "status":
                buff[0] = (byte) 0x24;
                buff[1] = (byte) 0x47;
                buff[2] = (byte) 0x41;
                buff[3] = (byte) 0x3f;
                buff[4] = (byte) 0xc7;
                break;
        }
        try {
            // serialPort.writeBytes(buff);
            for(int i=0; i<5; i++) {
            	serialPort.writeByte(buff[i]);
            }
            try { Thread.sleep(1000); } catch (Exception e) {}
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setConnected(boolean connected) {
        this.BILL_CONN = connected;
    }

    public boolean getConnected() {
        return this.BILL_CONN;
    }

    public /*synchronized*/void startActiveThread() {
    	active_stop = false;
        Thread thread = new Thread() {
            @Override
            public void run() {
                int i = 1;
                while(!active_stop) {
                    writeBlock("status");
//                    readBlock(); // 스레드 중지 후 메서드 재사용 
                    switch (ACTIVE_STATE) {
                        case 11:
                            writeBlock("bill_data");
//                            readBlock(); // 스레드 중지 후 메서드 재사용 
                            writeBlock("enable");
//                            readBlock(); // 스레드 중지 후 메서드 재사용 
                            break;
                    }
//                    try { Thread.sleep(500);  } catch (Exception e) {}
                    i++;
                }
            }
        };

        thread.setDaemon(true);
        thread.start();
    }
    
    public void stopActiveThread() {
    	active_stop = true;
    }

}