package application;
	
import java.io.IOException;

import application.util.BillUtil;
import application.util.DataBaseUtil;
import application.util.EjectorUtil;
import application.util.RFIDUtil;
import application.view.MainViewController;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


public class Main extends Application {
	
	private Stage primaryStage;
	
	public static BorderPane rootLayout;
	
	public static DataBaseUtil dataBase = new DataBaseUtil();
	public static BillUtil bill = new BillUtil(); 		   // 지폐인식기 참조 클래스 모듈
	public static EjectorUtil ejector = new EjectorUtil(); // 카드배출기 참조 클래스 모듈  
	public static RFIDUtil RFID = new RFIDUtil(); 		   // 카드리더기 참조 클래스 모듈  
	
	@FXML 
	private MediaView mv;
	    
	public static MediaPlayer mp;
	public static Media me;

	public static Process p; // 키보드
	
	public static boolean state_key = false;  // 키보드 플래그
	
	@Override
	public void start(Stage primaryStage) {
		
		this.primaryStage = primaryStage;
		this.primaryStage.setTitle("Touch Charger");
		
		initRootLayout();
		showRootLayout();
	}
	
	
	public void stopApp() {
		try {
			primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			    @Override
			    public void handle(WindowEvent t) {
			    	Platform.runLater(() -> {
			    		Platform.exit();
			    		System.exit(0);
			    	});
			    }
			});
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}
	
	public void initRootLayout() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/RootLayout.fxml"));
			rootLayout = (BorderPane) loader.load();
			
			Scene scene = new Scene(rootLayout);
			scene.getStylesheets().add(getClass().getResource("application.css").toString()); // CSS적용
			primaryStage.setScene(scene);
			primaryStage.setFullScreen(true); // Linux fullScreen
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void showRootLayout() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/MainView.fxml"));
			AnchorPane mainview = (AnchorPane) loader.load();
			rootLayout.setCenter(mainview);
			
			// 메인 어플리케이션 반환
			MainViewController main_controller = loader.getController();
			main_controller.setMainApp(this);
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public BorderPane getRootLayout() {
		return rootLayout;
	}
	
	public Stage getPrimaryStage() {
		return primaryStage;
	}
	
	public void setPrimaryStage(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}
	

	// UI ���� �޼��� 
	public static void main(String[] args) {
		launch(args);
	}
}
