package application.view;

import java.io.File;

import application.Main;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;


public class MainViewController {
	
	@FXML
	private Label lbl_main; // 저희 세차장
	
	@FXML
	private ImageView img_btn_charge;
	
	@FXML
	private ImageView img_btn_issued;
	
	@FXML
	private ImageView img_btn_lookup;
	
	@FXML
	private ImageView img_main_sound; // 이용하실 버튼 라벨
	
	@FXML
	private Label lbl_main_money; // 메인 투입금액 
	
	@FXML
	private Label lbl_hide_menu; // 관리자 메뉴
	
	private Main mainApp; // 메인 어플리케이션 반환 
	
	public static int ADMIN_CNT = 0;
	
	public boolean view_stop = false; // 뷰 금액 플래그 
	
	public boolean rf_stop = false; // 잔액조회 스레드 플래그 

	public boolean lbl_stop = false; // 메인 라벨 플래그 
	
	@FXML
	private void initialize() {
//		Main.dataBase.loadConfig();
		System.out.println("---------------------메인 페이지 초기화----------------------");

        Main.RFID.RFID_FLAG = 3; // 잔액 플래그
        
        Main.RFID.state_lookup = false; //  
        Main.RFID.state_charge = false; //
        Main.RFID.state_issued = false; //
        
	    if (Main.RFID.RFID_THREAD_STATE) {
        	Main.RFID.RFID_THREAD_STATE = false; // 리더기 시작 플래그
        	Main.RFID.handleReader();        	
        }
        
//        Main.bill.writeBlock("hi");
//        Main.bill.readBlock(); // 스레드 사용 X
		Main.bill.writeBlock("enable");
//		Main.bill.readBlock(); // 스레드 사용 X
		// 지폐인식기 꺼져있다면 ON 
		if (Main.bill.active_stop) { 
			Main.bill.startActiveThread(); // 지폐인식기 명령 스레드
		}

		changeViewMoney();
		mainViewLabel();
//		lookupThread();
		
//		handleBtnChargeSetting();
		handleBtnIssuedSetting();
		handleBtnLookupSetting();
		
		
	}
	
	// 충전 버튼 셋팅
	@FXML
	private void handleBtnChargeSetting() {
		Image image;
		if (Main.bill.BILL_CONN) {
			image = new Image("File:images/charge_on_btn.png");
		} else {
			image = new Image("File:images/charge_off_btn.png");			
		}
		img_btn_charge.setImage(image);
	}
	
    // 발급 버튼 셋팅  
	@FXML
	private void handleBtnIssuedSetting() {
		Image image;
		
		if (Main.ejector.EJECTOR_CONN) {
			image = new Image("File:images/issued_on_btn.png");
		} else {
			image = new Image("File:images/issued_off_btn.png");			
		}
		
		img_btn_issued.setImage(image);
	}
	
    // 조회 버튼 셋팅  
	@FXML
	private void handleBtnLookupSetting() {
		Image image;
		
		if (Main.RFID.RFID_CONN) {
			image = new Image("File:images/lookup_on_btn.png");
		} else {
			image = new Image("File:images/lookup_off_btn.png");			
		}
		
		img_btn_lookup.setImage(image);
	}
	
	@FXML
	private void handleBtnCharge() {
//		if (Main.bill.BILL_CONN) {
			try {
				Main.mp.stop();
	        } catch (NullPointerException e) {}
	        
	        String path = new File("msgs/msg005.wav").getAbsolutePath();
	        Main.me = new Media(new File(path).toURI().toString());
	        Main.mp = new MediaPlayer(Main.me);
	        Main.mp.play();
	        
			try {
				stopThread();
				FXMLLoader loader = new FXMLLoader();
				loader.setLocation(Main.class.getResource("view/ChargePage1.fxml"));
				AnchorPane paneCharge = (AnchorPane) loader.load();
				Main.rootLayout.setCenter(paneCharge);
				
				Main.RFID.RFID_FLAG = 1;

				ChargePage1Controller controller = loader.getController();
			    controller.setMainApp(mainApp);
				
			} catch(Exception e) {
				e.printStackTrace();
			}
//		} else {
//			Alert alert = new Alert(AlertType.WARNING);
//			alert.setTitle("경고");
//			alert.setHeaderText("에러");
//			alert.setContentText("지폐인식기 가 연결 되지 않았습니다.");
//			alert.showAndWait();
//			return;
//		}
	}
	
	@FXML
	private void handleBtnIssued() {
		if (Main.ejector.EJECTOR_CONN) {
			try {
				Main.mp.stop();
	        } catch (NullPointerException e) {}
	        
	        String path = new File("msgs/msg006.wav").getAbsolutePath();
	        Main.me = new Media(new File(path).toURI().toString());
	        Main.mp = new MediaPlayer(Main.me);
	        Main.mp.play();
			
			
			try {
				stopThread();
				FXMLLoader loader = new FXMLLoader();
				loader.setLocation(Main.class.getResource("view/IssuedPage.fxml"));
				AnchorPane mainview = (AnchorPane) loader.load(); 
				Main.rootLayout.setCenter(mainview);
				
				Main.RFID.RFID_FLAG = 2;
				
				IssuedPageController controller = loader.getController();
			    controller.setMainApp(mainApp);
				
			} catch(Exception e) {
				e.printStackTrace();
			}
		} else { 
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("경고");
			alert.setHeaderText("에러");
			alert.setContentText("카드배출기 가 연결 되지 않았습니다.");
			alert.showAndWait();
			return;
		}
	}
	
	@FXML
	private void handleBtnLookup() {
		
		if (Main.RFID.MONEY <= 0) {
			try {
				Main.mp.stop();
	        } catch (NullPointerException e) {}
	        
	        String path = new File("msgs/msg007.wav").getAbsolutePath();
	        Main.me = new Media(new File(path).toURI().toString());
	        Main.mp = new MediaPlayer(Main.me);
	        Main.mp.play();
		}
				
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/LookupPage.fxml"));
			AnchorPane mainview = (AnchorPane) loader.load();
			Main.rootLayout.setCenter(mainview); 
			Main.RFID.RFID_FLAG = 3;
			
			LookupPageController controller = loader.getController();
		    controller.setMainApp(mainApp);
//		    System.out.println("잔액조회 버튼 클릭 ");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	// 메인 금액 뷰 
	public void changeViewMoney() {
		view_stop = false;
        Thread thread = new Thread() {
            @Override
            public void run() {
                while (!view_stop) {
                    Platform.runLater(() -> {
                    	if (Main.bill.getBillTotalMoney() > 0) {
                    		lbl_main_money.setText("투입금액         " + String.format("%,d", Main.bill.getBillTotalMoney()) + " 원");
                    		lbl_main_money.setStyle("-fx-font-weight: bold");
                    		lbl_main_money.setStyle("-fx-text-fill : red");
                    	}
                    });
                    try { Thread.sleep(1000); } catch (InterruptedException e) {}
                }
            }
        };
        thread.setDaemon(true);
        thread.start();
    }
	
	// 잔액 조회 스레드 
	public void lookupThread() {
		rf_stop = false;
		Thread thread = new Thread() {
			@Override
			public void run() {
				while (!rf_stop) {
					Platform.runLater(() -> {
						if (Main.RFID.state_lookup) {
							try {
								Main.RFID.RFID_FLAG = 3;
								stopThread();
								handleBtnLookup();
							} catch(Exception e) {
								e.printStackTrace();
							}
						}
					});	
					try { Thread.sleep(1000); } catch (Exception e ) {}
				}
			}
			
		};
		thread.setDaemon(true);
		thread.start();
	}
	
	// 메인 모든 스레드 stop
	public void stopThread() {
		rf_stop = true;
		view_stop = true;
		lbl_stop = true;
	}
	
	public void mainViewLabel() {
		lbl_stop = false;		
        Thread thread = new Thread() {
            @Override
            public void run() {
                while (!lbl_stop) {
                    Platform.runLater(() -> {
                    	if(img_main_sound.isVisible()) {
                    		img_main_sound.setVisible(false);
                    	} else {
                    		img_main_sound.setVisible(true);
                    	}
                    });
                    try { Thread.sleep(1000); } catch (InterruptedException e) {}
                }
            }
        };
        thread.setDaemon(true);
        thread.start();
	}
	
	@FXML
	private void handleBindMenu() {
		ADMIN_CNT++;
		
		if(ADMIN_CNT == 3) {
			try {
				stopThread();
				Main.RFID.RFID_THREAD_STATE = true; 
				ADMIN_CNT = 0;
				FXMLLoader loader = new FXMLLoader();
				loader.setLocation(Main.class.getResource("view/LoginView.fxml"));
				AnchorPane mainview = (AnchorPane) loader.load();
				Main.rootLayout.setCenter(mainview); 
				
				LoginController controller = loader.getController();
			    controller.setMainApp(mainApp);
				
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void setMainApp(Main mainApp) {
		this.mainApp = mainApp;
	}
	
}
