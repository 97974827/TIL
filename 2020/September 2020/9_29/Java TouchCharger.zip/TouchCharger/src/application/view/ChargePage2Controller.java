package application.view;

import java.io.File;

import application.Main;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;


// [세차 카드터치 페이지]
public class ChargePage2Controller {
	
	@FXML
	private ImageView img_btn_back;
	
	@FXML
	private Label lbl_charge2_current_money; // 투입금액
	
	@FXML
	private Label lbl_charge2_current_bonus; // 보너스 
	
	public boolean view_stop = true; // 금액 뷰 플래그
	
	public boolean next_stop = true; // 충전완료 페이지 진입 플래그  
	
	public boolean card_sound_stop = true; // 세차 카드 터치 플래그
	
	private Main mainApp;
	
	
	@FXML
	private void initialize() {
		if (Main.mp.getStatus().equals("PLAYING")) {
        	Main.mp.stop();	
        }
		
		Main.RFID.RFID_THREAD_STATE = false;
		Main.RFID.handleReader();
		Main.bill.stopActiveThread(); // 지폐인식기 스레드 잠시 중지
		
		changeView();
		cardTouchSoundStart();
		nextView();
	}
	
	// 뷰 금액 변경
	public void changeView() {
        view_stop = false;
        Thread thread = new Thread() {
            @Override
            public void run() {
                while (!view_stop) {
                    Platform.runLater(() -> {
                    	if (Main.bill.getBillTotalMoney() > 0) {
                    		lbl_charge2_current_money.setText(String.format("%,d", Main.bill.USE_CURRENT_MONEY) + " 원");
                    		lbl_charge2_current_bonus.setText(String.format("%,d", Main.bill.USE_CURRENT_BONUS) + " 원");
                    	}
                    });
                    try { Thread.sleep(1000); } catch (InterruptedException e) {}
                }
            }
        };
        thread.setDaemon(true);
        thread.start();
    }
	
	// 세차 카드 터치 사운드 스래드
	public void cardTouchSoundStart() {
		card_sound_stop = false; 
		
		Thread thread = new Thread() {
			int cnt = 0;
			@Override
			public void run() {
				while(!card_sound_stop) {
					try {
						Main.mp.stop();
						String path = "";
						path = new File("msgs/msg010.wav").getAbsolutePath();
                        
//					        cnt++;
//					        count = cnt;
//					        if (cnt >= 20) {
////					       		Main.mp.stop();
//					        	System.out.println("지폐 투입안함");
//					        	path = new File("msgs/msg020.wav").getAbsolutePath();
////						        Main.me = new Media(new File(path).toURI().toString());
////						        Main.mp = new MediaPlayer(Main.me);
////						        Main.mp.play();
//					        }
					    
				        Main.me = new Media(new File(path).toURI().toString());
				        Main.mp = new MediaPlayer(Main.me);
				        Main.mp.play();
				        Thread.sleep(4000);	 // 여기에 멈춤
//					        if (cnt >= 20) {
////					        	Thread.sleep(4000);	 // 여기에 멈춤
//					        	System.out.println("메인으로");
//					        	Platform.runLater(() -> {
//					        		handleBack();
//					        	});
//					        }
				       
					} catch (Exception e) {}
				}
			}
		};
		thread.setDaemon(true);
		thread.start();
	}
	
	// 충전 완료 페이지 진입 스레드 
	public void nextView() {
        next_stop = false;
        Thread thread = new Thread() {
            @Override
            public void run() {
                while (!next_stop) {
                    Platform.runLater(() -> {
                    	if (Main.RFID.state_charge) {
                    		stopThread();
                    		handleNext();
                    	}
                    });
                    try { Thread.sleep(1000); } catch (InterruptedException e) {}
                }
            }
        };
        thread.setDaemon(true);
        thread.start();
    }

	// 스레드 중지 
	public void stopThread() {
		view_stop = true;
		next_stop = true;
		card_sound_stop = true;
		Main.mp.stop();
	}

	@FXML
	private void handleNext() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/ChargePage3.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			Main.rootLayout.setCenter(page);
			
			ChargePage3Controller controller = loader.getController();
		    controller.setMainApp(mainApp);
			
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	private void handleBack() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/MainView.fxml"));
			AnchorPane main = (AnchorPane) loader.load();
			Main.rootLayout.setCenter(main);
			MainViewController controller = loader.getController();
            controller.setMainApp(mainApp);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void setMainApp(Main mainApp) {
		this.mainApp = mainApp;
	}
	
}
