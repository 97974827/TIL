package application.view;

import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;
import java.util.Optional;

import application.Main;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class AdminViewController {
	
	@FXML
	private Button btn_admin_save;
	
	@FXML
	private Button btn_admin_cancel;
	
	@FXML
	private Button btn_sys_exit;
	
	@FXML 
	private Button btn_shopid_mode;
	
	@FXML
	private TextField textfield_bonus1;
	
	@FXML
	private TextField textfield_bonus2;

	@FXML
	private TextField textfield_bonus3;
	
	@FXML
	private TextField textfield_bonus4;

	@FXML
	private TextField textfield_bonus5;
	
	@FXML
	private TextField textfield_bonus6;
	
	@FXML
	private TextField textfield_bonus7;
	
	@FXML
	private TextField textfield_bonus8;
	
	@FXML
	private TextField textfield_bonus9;
	
	@FXML
	private TextField textfield_bonus10;
	
	@FXML
	private Label lbl_version;
	
	@FXML
	private TextField textfield_password;
	
	@FXML
	private TextField textfield_card_price;
	
	@FXML
	private TextField textfield_min_card_price;
	
	@FXML
	private TextField textField_shopid;
	
	private Main mainApp;
	
	@FXML
	private void initialize() {
		Main.bill.stopActiveThread();
		textfield_bonus1.setText(String.format("%,d", Integer.parseInt(Main.dataBase.getConfigData().get("bonus1"))));
		textfield_bonus2.setText(String.format("%,d", Integer.parseInt(Main.dataBase.getConfigData().get("bonus2"))));
		textfield_bonus3.setText(String.format("%,d", Integer.parseInt(Main.dataBase.getConfigData().get("bonus3"))));
		textfield_bonus4.setText(String.format("%,d", Integer.parseInt(Main.dataBase.getConfigData().get("bonus4"))));
		textfield_bonus5.setText(String.format("%,d", Integer.parseInt(Main.dataBase.getConfigData().get("bonus5"))));
		textfield_bonus6.setText(String.format("%,d", Integer.parseInt(Main.dataBase.getConfigData().get("bonus6"))));
		textfield_bonus7.setText(String.format("%,d", Integer.parseInt(Main.dataBase.getConfigData().get("bonus7"))));
		textfield_bonus8.setText(String.format("%,d", Integer.parseInt(Main.dataBase.getConfigData().get("bonus8"))));
		textfield_bonus9.setText(String.format("%,d", Integer.parseInt(Main.dataBase.getConfigData().get("bonus9"))));
		textfield_bonus10.setText(String.format("%,d", Integer.parseInt(Main.dataBase.getConfigData().get("bonus10"))));
		
		textfield_password.setText(Main.dataBase.getConfigData().get("admin_password"));
		byte[] decoded = Base64.getDecoder().decode(textfield_password.getText().toString());
		String str = new String(decoded, StandardCharsets.UTF_8);
		textfield_password.setText(str);
		
		textfield_card_price.setText(String.format("%,d", Integer.parseInt(Main.dataBase.getConfigData().get("card_price"))));
		textfield_min_card_price.setText(String.format("%,d", Integer.parseInt(Main.dataBase.getConfigData().get("min_card_price"))));
		
		textField_shopid.setText(Main.dataBase.getConfigData().get("id"));
		lbl_version.setText(Main.dataBase.getConfigData().get("version"));
	}
	
	public void killKeyBoard() {
		Platform.runLater(new Runnable() {
			@Override
		    public void run() {
				try {
					if(Main.state_key) {
						Main.state_key = false;
						Main.p.destroy();
					}
		    	} catch (Exception e) { 
		    		e.printStackTrace();
				}
			}
		});
	}
	
	@FXML
	private void handleSave() {
		try {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("확인");
			alert.setContentText("저장하시겠습니까?");
			
			ButtonType okButton = new ButtonType("yes");
			ButtonType cancelButton = new ButtonType("no");
			//alert.getButtonTypes().setAll(okButton, cancelButton);
			
			Optional<ButtonType> result = alert.showAndWait();
			
			if (result.get() == ButtonType.OK){
				setAdminSave();
				handleBack();
			} else {
				return;
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void setAdminSave() {
		Connection conn = null; // DB conn  
		PreparedStatement  stmt = null;  // sql 실행 객체
		ResultSet rs = null;    // sql 결과 객체
		
		try {
			Class.forName(Main.dataBase.getJDBC_DRIVER());  
			conn = DriverManager.getConnection(Main.dataBase.getMYSQL_HOST(), Main.dataBase.getMYSQL_USER(), Main.dataBase.getMYSQL_PWD()); 
			
			String sql = "UPDATE config SET  bonus1=?, bonus2=?, bonus3=?, bonus4=?, bonus5=?, " 
					   + "bonus6=?, bonus7=?, bonus8=?, bonus9=?, bonus10=?, " 
					   + "card_price=?, id=?, admin_password=?, min_card_price=?";
			stmt = conn.prepareStatement(sql);
			
//			map_config_data.put("bonus1", textfield_bonus1.getText());
//			Main.dataBase.setConfigData(map_config_data);
			
			stmt.setString(1, textfield_bonus1.getText().replace(",", ""));
			stmt.setString(2, textfield_bonus2.getText().replace(",", ""));
			stmt.setString(3, textfield_bonus3.getText().replace(",", ""));
			stmt.setString(4, textfield_bonus4.getText().replace(",", ""));
			stmt.setString(5, textfield_bonus5.getText().replace(",", ""));
			stmt.setString(6, textfield_bonus6.getText().replace(",", ""));
			stmt.setString(7, textfield_bonus7.getText().replace(",", ""));
			stmt.setString(8, textfield_bonus8.getText().replace(",", ""));
			stmt.setString(9, textfield_bonus9.getText().replace(",", ""));
			stmt.setString(10, textfield_bonus10.getText().replace(",", ""));
			
//			int card_price = Integer.parseInt(textfield_card_price.getText().replace(",", ""));
			stmt.setInt(11, Integer.parseInt(textfield_card_price.getText().replace(",", "")));
			stmt.setString(12, textField_shopid.getText());
			
			byte[] encoded = Base64.getEncoder().encode(textfield_password.getText().getBytes());
			String str = new String(encoded, StandardCharsets.UTF_8);
			
			stmt.setString(13, str);
			stmt.setInt(14, Integer.parseInt(textfield_min_card_price.getText().replace(",", "")));
			
			stmt.executeUpdate(); // 실행
			
			Main.dataBase.loadConfig();
			
		} catch(ClassNotFoundException e) {
			System.out.println("드라이버 로딩 실패  >> " + e);
			e.printStackTrace();
		} catch(SQLException e) {
			System.out.println("Exception >> " + e);
			e.printStackTrace();
		} finally {
			try {
				if(stmt != null && !stmt.isClosed()) {
					stmt.close();
				}
				if(conn != null && !conn.isClosed()) {
					conn.close();
				}
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	@FXML
	private void handleBack() {
		try {
			killKeyBoard();
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/MainView.fxml"));
			AnchorPane pane = (AnchorPane) loader.load();
			Main.rootLayout.setCenter(pane);
			MainViewController main_controller = loader.getController();
			main_controller.setMainApp(mainApp);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	public void handleProgramExit(ActionEvent event) {
		System.out.println("프로그램 종료");
		Main.bill.closeSerial();
		Main.ejector.closeSerial();
		Main.RFID.closeReader();
		killKeyBoard();
	    Stage stage = (Stage) btn_sys_exit.getScene().getWindow();
	    stage.close();
	}
	
	
	@FXML
	private void handleCardInit() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/InitCardView.fxml"));
			AnchorPane pane = (AnchorPane) loader.load();
			Main.rootLayout.setCenter(pane);
			
			InitCardViewController controller = loader.getController();
			controller.setMainApp(mainApp);
			killKeyBoard();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	public void setMainApp(Main mainApp) {
		this.mainApp = mainApp;
	}
	
}
