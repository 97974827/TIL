package application.view;

import java.io.File;

import application.Main;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;


// [충전/발급 완료 페이지 ]
public class ChargePage3Controller {
	
	@FXML
	private Label lbl_charge3_total_money; // 총 충전금액 
	
	public boolean view_stop = true; // 금액 뷰 스레드 플래그
	
	public boolean delay_stop = true; // 딜레이 플래그
	
	private Main mainApp;
	
	public int card_price = Integer.parseInt(Main.dataBase.getConfigData().get("card_price"));
	
	@FXML
	private void initialize() {
		chargeTotalMoneyThread();
	}
	

	// 총 충전 금액 뷰 스레드
	public void chargeTotalMoneyThread() {
		Main.mp.stop();
		Main.bill.stopActiveThread(); // 지폐인식기 스레드 잠시 중지
		
		if (Main.bill.getBillTotalMoney() > 0) {
			System.out.println("충전 완료 페이지 금액은  : " + Main.RFID.TOTAL_MONEY);
			System.out.println("발급 완료 페이지 금액은  : " + Main.bill.issued_money); 
			
			if(Main.RFID.RFID_FLAG == 1) {
				lbl_charge3_total_money.setText(String.format("%,d", Main.RFID.TOTAL_MONEY) + " 원");
			} else if (Main.RFID.RFID_FLAG == 2) {
				lbl_charge3_total_money.setText(String.format("%,d", Main.bill.issued_money - card_price) + " 원");
			}
    		delayThread();
    	}
	}
	
	
	public void delayThread() {
        delay_stop = false;
        Thread thread = new Thread() {
            @Override
            public void run() {
            	try {
//	        		Main.mp.stop();
	        	} catch (NullPointerException e) {}
	        	
	            String path = new File("msgs/msg013.wav").getAbsolutePath();
	            Main.me = new Media(new File(path).toURI().toString());
	            Main.mp = new MediaPlayer(Main.me);
	            Main.mp.play();
	            
                try {Thread.sleep(4000);} catch (InterruptedException e) {}
                
                Platform.runLater(() -> {
                	System.out.println("Main.RFID.state_charge : " + Main.RFID.state_charge);
                	System.out.println("Main.RFID.state_issued : " + Main.RFID.state_issued);
                	if(Main.RFID.state_charge || Main.RFID.state_issued) {
	                    delay_stop = true;
	                    try {
	                    	Main.RFID.MONEY = 0;			
	                        Main.RFID.TOTAL_MONEY = 0;
	                        Main.bill.setBillTotalMoney(0);
	                        Main.bill.setBillCurrentBonus(0);
	                        Main.bill.setBillCurrentMoney(0);
	                        Main.bill.USE_CURRENT_MONEY = 0;
	                        Main.bill.USE_CURRENT_BONUS = 0;
	                        Main.RFID.RFID_FLAG = 3;    
	                        handleBack();
	                    } catch (Exception e) {
	                        e.printStackTrace();
	                    }
                	}
                });
            }
        };

        thread.setDaemon(true);
        thread.start();
    }
	
	@FXML
	private void handleBack() {
		try {
			//Main.mp.stop();
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/MainView.fxml"));
			AnchorPane main = (AnchorPane) loader.load();
			Main.rootLayout.setCenter(main);
			MainViewController controller = loader.getController();
            controller.setMainApp(mainApp);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void setMainApp(Main mainApp) {
		this.mainApp = mainApp;
	}
}
