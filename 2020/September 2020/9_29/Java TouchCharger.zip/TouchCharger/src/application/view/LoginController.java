package application.view;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import application.Main;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;


public class LoginController {
	
	@FXML
	private Button btn_comfirm;
	
	@FXML
	private Button btn_cancel;
	
	@FXML
	private TextField text_field_pw;
	
	private Main mainApp;
	
	public void addKeyBoard() {
		Platform.runLater(new Runnable() {
			@Override
		    public void run() {
				try {
					String exe_keyborad = "/usr/bin/florence";						 
					Main.p = Runtime.getRuntime().exec(exe_keyborad);
					Main.state_key = true;
		    	} catch (Exception e) { 
		    		e.printStackTrace();
				}
			}
		});
	}
	
	@FXML
	private void initialize() {
		Main.bill.stopActiveThread(); // 지폐인식기 스레드 잠시 중지
		Main.RFID.stopReader(); // 리더기 잠시중지
		
		text_field_pw.setText("");

		// Text Foucsing
		Platform.runLater(new Runnable() {
		    @Override
		    public void run() {
		        text_field_pw.requestFocus();
		    }
		});
		
		addKeyBoard();
		
		// Enter key Event
		text_field_pw.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent keyEvent) {
				if (keyEvent.getCode() == KeyCode.ENTER) {  
					handleSuccess();
				}
			}
		});
	}
	
	@FXML
	private void handleCancel() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/MainView.fxml"));
			AnchorPane main = (AnchorPane) loader.load();
			Main.rootLayout.setCenter(main);
			
			Platform.runLater(new Runnable() {
				@Override
			    public void run() {
					try {
						if(Main.state_key) {
							Main.state_key = false;
							Main.p.destroy();
						}
			    	} catch (Exception e) { 
			    		e.printStackTrace();
					}
				}
			});
			
		} catch(Exception e) {
			e.printStackTrace();
		}			
	}
	
	@FXML
	private void handleSuccess() {
		String input = "";
		input = text_field_pw.getText();
		
		if(input.equals("1234")) {
			try {
				FXMLLoader loader = new FXMLLoader();
				loader.setLocation(Main.class.getResource("view/AdminView.fxml"));
				AnchorPane adminPane = (AnchorPane) loader.load();
				Main.rootLayout.setCenter(adminPane);
				AdminViewController admin = loader.getController();
				admin.setMainApp(mainApp);
				
			} catch(Exception e) {
				e.printStackTrace();
			}
		} else if(input.equals("gls12q23w")) {
			try {
				FXMLLoader loader = new FXMLLoader();
				loader.setLocation(Main.class.getResource("view/MasterView.fxml"));
				AnchorPane master = (AnchorPane) loader.load();
				Main.rootLayout.setCenter(master);
				MasterViewController controller = loader.getController();
				controller.setMainApp(mainApp);
				
			} catch(Exception e) {
				e.printStackTrace();
			}
		} else { // TODO 9.25 팝업창이 가려져서 나옴 
			if (Main.state_key) {
				Main.state_key = false;
				Main.p.destroy();
			}
			text_field_pw.setText("");
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("인증");
			alert.setHeaderText("로그인 실패");
			alert.setContentText("잘못된 비밀번호 입니다.");
			alert.showAndWait();
			return;
		}
	}
	
	
	public void setMainApp(Main mainApp) {
		this.mainApp = mainApp;
	}
	
}
