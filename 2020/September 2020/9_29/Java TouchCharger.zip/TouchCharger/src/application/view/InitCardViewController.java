package application.view;

import application.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

public class InitCardViewController {
	

	@FXML
	private ImageView btn_img_init_start; // 등록 시작  
	
	@FXML
	private ImageView btn_img_init_cancel; // 등록종료
	
	@FXML
	private Label lbl_init_state; // 카드 상태 
	
	@FXML
	private Label lbl_shop_id; // 등록될 매장 ID
	
	public boolean view_stop = true;  
	
	
	
	private Main mainApp;
	
	@FXML
	private void initialize() {
		
	}
	
	@FXML
	private void viewChange() {
		view_stop = false;
		Thread thread = new Thread(){
			@Override
			public void run() {
				while(!view_stop) {
					
					
					try { Thread.sleep(1000); } catch(Exception e) {}
				} 
			}
		};
		thread.setDaemon(true);
		thread.start();
	}
	
	public void stopInit() {
		view_stop = true;
	}
	
	@FXML
	private void handleBack() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/MainView.fxml"));
			AnchorPane pane = (AnchorPane) loader.load();
			Main.rootLayout.setCenter(pane);
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void setMainApp(Main mainApp) {
		this.mainApp = mainApp;
	}
	
}
