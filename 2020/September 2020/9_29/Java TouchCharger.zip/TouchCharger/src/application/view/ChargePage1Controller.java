package application.view;

import java.io.File;

import application.Main;
import application.util.BillUtil;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;


// [카드충전 선택 페이지 ]
public class ChargePage1Controller {
	
	@FXML
	private ImageView img_btn_back;
	
	@FXML
	private ImageView img_btn_next_off; // 다음 off
	
	@FXML
	private ImageView img_btn_gif;  // 다음 활성 gif
	
	@FXML
	private ImageView img_gif_bill; 
	
	@FXML
	private Label lbl_charge_money;
	
	public boolean view_stop = true; // 금액 뷰 스레드 플래그 
	
	public boolean billsound_stop = true; // 지폐 투입 사운드 플래그 
	
	public static int count = 0;
	
	private Main mainApp;
	
	@FXML
	private void initialize() {
		System.out.println("------------------------충전----------------------------");
		Main.RFID.RFID_FLAG = 1;
		Main.RFID.stopReader(); // 리더기 잠시 off
		changeCurrentMoney();
		billSoundStart();
	}
	
	// 투입금액+보너스 변경 뷰 스레드 
	public void changeCurrentMoney() {
		view_stop = false;
        Thread thread = new Thread() {
            @Override
            public void run() {
                while (!view_stop) {
                    Platform.runLater(() -> {
                    	if (Main.bill.getBillTotalMoney() > 0) {
                    		lbl_charge_money.setText(String.format("%,d", Main.bill.getBillTotalMoney()) + " 원");
                    		img_btn_next_off.setVisible(false);
                    		img_btn_gif.setVisible(true);
                    	}
                    });
                    try { Thread.sleep(1000); } catch (InterruptedException e) {}
                }
            }
        };
        thread.setDaemon(true);
        thread.start();
    }
	
	// 지폐 투입 사운드 활성화 
	public void billSoundStart() {
		billsound_stop = false;
//		try { Thread.sleep(4000); } catch (InterruptedException e) {}
		Thread thread = new Thread() {
			int cnt = 0;
			@Override
			public void run() {
				while(!billsound_stop) {
					try { Thread.sleep(6000); } catch (InterruptedException e) {}
					System.out.println("지폐투입 사운드");
					try {
						String path = "";
						if (Main.bill.getBillTotalMoney() > 0) {
							//Main.mp.stop();
							path = new File("msgs/msg009.wav").getAbsolutePath();
                        } else {
                        	path = new File("msgs/msg008.wav").getAbsolutePath();
                        }
				        
				        System.out.println(Main.mp.getStatus().toString());

//				        cnt++;
//				        count = cnt;
//				        if (cnt >= 20) {
////				       		Main.mp.stop();
//				        	System.out.println("지폐 투입안함");
//				        	path = new File("msgs/msg020.wav").getAbsolutePath();
////					        Main.me = new Media(new File(path).toURI().toString());
////					        Main.mp = new MediaPlayer(Main.me);
////					        Main.mp.play();
//				        }
				        
				        Main.me = new Media(new File(path).toURI().toString());
				        Main.mp = new MediaPlayer(Main.me);
				        Main.mp.play();
				        
//				        if (cnt >= 20) {
////				        	Thread.sleep(4000);	 // 여기에 멈춤
//				        	System.out.println("메인으로");
//				        	Platform.runLater(() -> {
//				        		handleBack();
//				        	});
//				        }
				       
					} catch (Exception e) {}
				}
			}
		};
		thread.setDaemon(true);
		thread.start();
	}
	
	public void stopChargeThread() {
		System.out.println("스레드 중지");
		view_stop = true;
		billsound_stop = true;
        Main.mp.stop();	
//		if(count >= 20) {  try { Thread.sleep(3500); } catch(Exception e) {} }
	}
	
	@FXML
	private void handleBack() {
		try {
			stopChargeThread();
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/MainView.fxml"));
			AnchorPane main = (AnchorPane) loader.load();
			Main.rootLayout.setCenter(main);
			MainViewController main_controller = loader.getController();
			main_controller.setMainApp(mainApp);
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	private void handleNext() {
		try {
			stopChargeThread();
			
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/ChargePage2.fxml"));
			AnchorPane page_2 = (AnchorPane) loader.load();
			Main.rootLayout.setCenter(page_2);
			
			ChargePage2Controller controller = loader.getController();
		    controller.setMainApp(mainApp);
			
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void setMainApp(Main mainApp) {
		this.mainApp = mainApp;
	}
}
