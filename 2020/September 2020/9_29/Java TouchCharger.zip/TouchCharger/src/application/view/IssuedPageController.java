package application.view;

import java.io.File;

import application.Main;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;


// [카드발급]
public class IssuedPageController {
	
	@FXML
	private ImageView img_btn_back;
	
	@FXML
	private ImageView img_btn_next_off;
	
	@FXML
	private ImageView img_btn_gif;
	
	@FXML
	private ImageView img_gif_bill;
	
	@FXML
	private Label lbl_charge_money; // 투입금액 + 보너스 
	
	@FXML
	private Label lbl_card_price; // 카드 발급 금액 (최소금액아님)
	
	public int card_price = Integer.parseInt(Main.dataBase.getConfigData().get("card_price"));
	public int min_card_price = Integer.parseInt(Main.dataBase.getConfigData().get("min_card_price"));
	
	public boolean issued_stop = true; // 금액 뷰 플래그
	
	public boolean billsound_stop = true; // 지폐 투입 사운드 플래그 
	
	public boolean next_stop = true; // 발급 완료 페이지 진입 플래그 
	
	private Main mainApp;
	
	
	@FXML
	private void initialize() {
		System.out.println("------------------발급----------------------------");
		lbl_card_price.setText(String.format("%,d", card_price) + " 원");
		Main.RFID.RFID_FLAG = 2;
		Main.RFID.stopReader(); // 리더기 잠시 off
		changeIssuedMoney();
		billSoundStart();
	}
	
	// 금액 뷰 스레드 
	public void changeIssuedMoney() {
		issued_stop = false;
        Thread thread = new Thread() {
            @Override
            public void run() {
                while (!issued_stop) {
                    Platform.runLater(() -> {
                    	if (Main.bill.getBillTotalMoney() >= min_card_price) {
                    		lbl_charge_money.setText(String.format("%,d", Main.bill.getBillTotalMoney()) + " 원");
                    		img_btn_next_off.setVisible(false);
                    		img_btn_gif.setVisible(true);
                    	}
                    });
                    try { Thread.sleep(1000); } catch (InterruptedException e) {}
                }
            }
        };
        thread.setDaemon(true);
        thread.start();
    }
	
	// 지폐 투입 사운드 활성화 
	public void billSoundStart() {
		billsound_stop = false;
		
		Thread thread = new Thread() {
			int cnt = 0;
			@Override
			public void run() {
				while(!billsound_stop) {
					try {
						Thread.sleep(6000);	 // 여기에 멈춤
						String path = "";
						if (Main.bill.getBillTotalMoney() > 0) {
							//Main.mp.stop();
							path = new File("msgs/msg009.wav").getAbsolutePath();
                        } else {
                        	path = new File("msgs/msg008.wav").getAbsolutePath();
                        }
				        
			        
				        Main.me = new Media(new File(path).toURI().toString());
				        Main.mp = new MediaPlayer(Main.me);
				        Main.mp.play();
				        
				        //billsound_stop = true;
					} catch (Exception e) {}
				}
			}
		};
		thread.setDaemon(true);
		thread.start();
	}
	
	// 발급
	@FXML
	private void handleNext() {
		try {
			if (Main.bill.getBillTotalMoney() >= min_card_price) {
				Platform.runLater(() -> {
					Main.bill.stopActiveThread();
					System.out.println("카드 뱉어라");
					Main.ejector.writeBlock("output");
					stopIssuedThread();
					try { Thread.sleep(3500); } catch(Exception e) {}
//					Main.RFID.RFID_FLAG = 2; // 발급 플래그 유지
//					Main.RFID.state_issued = true;
					System.out.println("Main.RFID.state_issued : " + Main.RFID.state_issued);
					Main.RFID.chargeCard();
				});
			}
			System.out.println("발급 했을때 금액은 얼마인가 ? : " + Main.bill.issued_money );
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/ChargePage3.fxml"));
			AnchorPane main = (AnchorPane) loader.load();
			Main.rootLayout.setCenter(main);
			
			ChargePage3Controller controller = loader.getController();
		    controller.setMainApp(mainApp);
			
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	// 발급 완료 진입 스레드
	public void nextView() {
		next_stop = false;
        Thread thread = new Thread() {
            @Override
            public void run() {
                while (!next_stop) {
                    Platform.runLater(() -> {
                    	if (Main.RFID.RFID_THREAD_STATE) {
                    		stopIssuedThread();
                    		handleNext();
                    	}
                    });
                    try { Thread.sleep(1000); } catch (InterruptedException e) {}
                }
            }
        };
        thread.setDaemon(true);
        thread.start();
    }
	
	public void stopIssuedThread() {
		Main.mp.stop();	
		issued_stop = true;
		next_stop = true;
		billsound_stop = true;  
	}
	
	// 뒤로가기
	@FXML
	private void handleBack() {
		try {
			stopIssuedThread();
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/MainView.fxml"));
			AnchorPane main = (AnchorPane) loader.load();
			Main.rootLayout.setCenter(main);
			
			MainViewController main_controller = loader.getController();
			main_controller.setMainApp(mainApp);
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void setMainApp(Main mainApp) {
		this.mainApp = mainApp;
	}
}
