package application.view;

import java.io.File;

import application.Main;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;


// [잔액조회]
public class LookupPageController {
	
	@FXML
	private ImageView img_btn_back;
	
	@FXML
	private Label lbl_lookup_current_money; // 현재 잔액  
	
	public boolean stop = false;
	
	public boolean card_sound_stop = true; // 세차 카드 터치 플래그
	
	public static int count = 0;
	
	private Main mainApp;
	
	@FXML
	private void initialize() {
		System.out.println("잔액조회 페이지 진입");
//		try {Thread.sleep(3000);} catch (InterruptedException e) {}
		viewMoneyStart();
		cardTouchSoundStart();
	}
	
	public void viewMoneyStart() {
		try {Thread.sleep(1000);} catch (InterruptedException e) {}
		stop = false;
		Thread thread = new Thread() {
			@Override
			public void run() {
				while (!stop) {
					int money = Main.RFID.MONEY;
					String path = "";
					
					if (Main.RFID.state_lookup) {
						Platform.runLater(() -> {
							System.out.println("잔액 변환  : " + Main.RFID.MONEY);
							lbl_lookup_current_money.setText(String.format("%,d", money) + " 원");
						});	
						
//	            		Main.mp.stop();
//		                path = new File("msgs/msg018.wav").getAbsolutePath(); // 조회완료 
//		                Main.me = new Media(new File(path).toURI().toString());
//		                Main.mp = new MediaPlayer(Main.me);
//		                Main.mp.play();
//		                //try {Thread.sleep(2000);} catch (InterruptedException e) {}
//						stopThread();
//						Main.RFID.MONEY = 0;
//						delayThread();
					} 
					try {Thread.sleep(1000);} catch (InterruptedException e) {}
					
//					Platform.runLater(() -> {
//						if (money > 0) {
//							System.out.println("잔액 변환  : " + Main.RFID.MONEY);
//							lbl_lookup_current_money.setText(String.format("%,d", money) + " 원");
//							
//							stopThread();
//							Main.RFID.MONEY = 0;
//							delayThread();
//						}
//					});	
					
				}
			}
		};
		thread.setDaemon(true);
		thread.start();
	}
	
	// 세차 카드 터치 사운드 스래드
	public void cardTouchSoundStart() {
		card_sound_stop = false; 
		
		Thread thread = new Thread() {
			int cnt = 0;
			@Override
			public void run() {
				while(!card_sound_stop) {
					try {
						Thread.sleep(3000);	 // 여기에 멈춤
						String path = "";
						
						if (!Main.RFID.state_lookup) { // 카드 대지않았을떄 
							System.out.println("카드 X");
							Main.mp.stop();
							path = new File("msgs/msg010.wav").getAbsolutePath();
					        Main.me = new Media(new File(path).toURI().toString());
					        Main.mp = new MediaPlayer(Main.me);
					        Main.mp.play();
						} else {
							System.out.println("카드 O");
			                path = new File("msgs/msg018.wav").getAbsolutePath(); // 조회완료 
			                Main.me = new Media(new File(path).toURI().toString());
			                Main.mp = new MediaPlayer(Main.me);
			                Main.mp.play();
			                try {Thread.sleep(2000);} catch (InterruptedException e) {}
							stopThread();
							Main.RFID.MONEY = 0;
							delayThread();
						}

			       
					} catch (Exception e) {}
				}
			}
		};
		thread.setDaemon(true);
		thread.start();
	}
	
	public void stopThread() {
		System.out.println("조회 스레드 중지");
		stop = true;
		card_sound_stop = true;
		Main.RFID.state_lookup = false;
		Main.mp.stop();
//		if (Main.mp.getStatus().equals("PLAYING")) { Main.mp.stop(); }
	}
	
    public void delayThread() {
        Thread thread = new Thread() {
        	@Override
        	public void run() {
        		try {Thread.sleep(1000);} catch (InterruptedException e) {}
    			Platform.runLater(() -> {
					handleBack(); // 메인으로
                });
            }
        };
        thread.setDaemon(true);
        thread.start();
    }
	
	@FXML
	private void handleBack() {
		try {
			stopThread();
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/MainView.fxml"));
			AnchorPane main = (AnchorPane) loader.load();
			Main.rootLayout.setCenter(main);
			MainViewController main_controller = loader.getController();
			main_controller.setMainApp(mainApp);
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	public void setMainApp(Main mainApp) {
		this.mainApp = mainApp;
	}
}
